import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { OverviewSection } from './components/OverviewSection';
import { UserFlowSection } from './components/UserFlowSection';
import { DataFormatsSection } from './components/DataFormatsSection';
import { ArchitectureSection } from './components/ArchitectureSection';
import { MLApproachesSection } from './components/MLApproachesSection';
import { SecuritySection } from './components/SecuritySection';
import { PerformanceSection } from './components/PerformanceSection';
import { APISection } from './components/APISection';
import { RoadmapSection } from './components/RoadmapSection';
import { TestingSection } from './components/TestingSection';
import { ScrollArea } from './components/ui/scroll-area';
import { FileText, Shield, Zap, Code, Map, Database, Brain, CheckCircle, FlaskConical } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="border-b bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <FileText className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-slate-900">Voice Caller ID App</h1>
              <p className="text-slate-600 text-sm">Technical Specification & Implementation Plan</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-10 gap-2 h-auto bg-white p-2 rounded-lg shadow-sm">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="userflow" className="flex items-center gap-2">
              <Map className="h-4 w-4" />
              <span className="hidden sm:inline">User Flow</span>
            </TabsTrigger>
            <TabsTrigger value="data" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              <span className="hidden sm:inline">Data</span>
            </TabsTrigger>
            <TabsTrigger value="architecture" className="flex items-center gap-2">
              <Code className="h-4 w-4" />
              <span className="hidden sm:inline">Architecture</span>
            </TabsTrigger>
            <TabsTrigger value="ml" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              <span className="hidden sm:inline">ML & APIs</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <span className="hidden sm:inline">Security</span>
            </TabsTrigger>
            <TabsTrigger value="performance" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">Performance</span>
            </TabsTrigger>
            <TabsTrigger value="api" className="flex items-center gap-2">
              <Code className="h-4 w-4" />
              <span className="hidden sm:inline">API</span>
            </TabsTrigger>
            <TabsTrigger value="roadmap" className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Roadmap</span>
            </TabsTrigger>
            <TabsTrigger value="testing" className="flex items-center gap-2">
              <FlaskConical className="h-4 w-4" />
              <span className="hidden sm:inline">Testing</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <OverviewSection />
          </TabsContent>

          <TabsContent value="userflow">
            <UserFlowSection />
          </TabsContent>

          <TabsContent value="data">
            <DataFormatsSection />
          </TabsContent>

          <TabsContent value="architecture">
            <ArchitectureSection />
          </TabsContent>

          <TabsContent value="ml">
            <MLApproachesSection />
          </TabsContent>

          <TabsContent value="security">
            <SecuritySection />
          </TabsContent>

          <TabsContent value="performance">
            <PerformanceSection />
          </TabsContent>

          <TabsContent value="api">
            <APISection />
          </TabsContent>

          <TabsContent value="roadmap">
            <RoadmapSection />
          </TabsContent>

          <TabsContent value="testing">
            <TestingSection />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t bg-white mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-slate-600 text-sm">
          <p>Voice Caller ID App - Technical Specification v1.0</p>
          <p className="mt-2">Created: October 24, 2025</p>
        </div>
      </footer>
    </div>
  );
}
