import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

export function MLApproachesSection() {
  const approaches = [
    {
      category: "Speech-to-Text (STT)",
      options: [
        {
          name: "Google Speech-to-Text API",
          pros: ["115+ languages", "High accuracy", "Speaker diarization", "Real-time & batch"],
          cons: ["Cost: $0.006-0.024/15s", "Privacy: data sent to Google", "Network dependency"],
          privacy: "high-risk",
          recommendation: "Best for MVP - proven accuracy"
        },
        {
          name: "AWS Transcribe",
          pros: ["Custom vocabulary", "Medical/legal variants", "Multi-language", "Auto language detection"],
          cons: ["Cost: $0.024/min", "Limited to AWS ecosystem", "Privacy concerns"],
          privacy: "high-risk",
          recommendation: "Good if already on AWS"
        },
        {
          name: "Whisper (OpenAI) - Self-hosted",
          pros: ["Free & open source", "98+ languages", "Very accurate", "Full data control", "No API costs"],
          cons: ["Requires GPU (inference time)", "Self-hosting complexity", "Model size (1.5GB+)"],
          privacy: "low-risk",
          recommendation: "Best for privacy - recommended for production"
        },
        {
          name: "Mozilla DeepSpeech",
          pros: ["Open source", "Self-hosted", "Privacy-friendly"],
          cons: ["Limited language support", "Lower accuracy than Whisper", "Less maintained"],
          privacy: "low-risk",
          recommendation: "Not recommended - use Whisper instead"
        }
      ]
    },
    {
      category: "Speaker Identification / Voice Biometrics",
      options: [
        {
          name: "Azure Speaker Recognition",
          pros: ["Text-independent verification", "Speaker identification", "Good accuracy"],
          cons: ["Cost: $0.50/1000 transactions", "Microsoft privacy policy applies", "Proprietary"],
          privacy: "high-risk",
          recommendation: "Good accuracy but privacy concerns"
        },
        {
          name: "Resemblyzer (Open Source)",
          pros: ["Free", "Self-hosted", "Based on GE2E loss", "Easy to use", "Privacy-friendly"],
          cons: ["Requires voice samples database", "Lower accuracy than commercial", "No official support"],
          privacy: "low-risk",
          recommendation: "Recommended for MVP - good balance"
        },
        {
          name: "pyannote.audio",
          pros: ["Open source", "Speaker diarization", "Active development", "Research-backed"],
          cons: ["Complex setup", "Requires training data", "GPU needed for real-time"],
          privacy: "low-risk",
          recommendation: "Best for advanced features"
        },
        {
          name: "Custom CNN Model",
          pros: ["Full control", "Optimizable", "No third-party deps"],
          cons: ["Requires ML expertise", "Need large training dataset", "Development time"],
          privacy: "low-risk",
          recommendation: "Future consideration after MVP"
        }
      ]
    },
    {
      category: "Language Detection",
      options: [
        {
          name: "Google Cloud Speech (built-in)",
          pros: ["Automatic", "115+ languages", "High accuracy", "Accent detection"],
          cons: ["Bundled with STT cost", "Privacy concerns"],
          privacy: "high-risk",
          recommendation: "Use if using Google STT"
        },
        {
          name: "librosa + langdetect",
          pros: ["Free", "Language detection from text", "Open source"],
          cons: ["Requires transcription first", "Less accurate on short clips"],
          privacy: "low-risk",
          recommendation: "Good free alternative"
        },
        {
          name: "Meta MMS (Massively Multilingual Speech)",
          pros: ["1000+ languages", "Open source", "State-of-the-art", "Self-hosted"],
          cons: ["Large model size", "GPU required", "Complex setup"],
          privacy: "low-risk",
          recommendation: "Best for extensive language support"
        }
      ]
    },
    {
      category: "Gender & Age Estimation",
      options: [
        {
          name: "openSMILE + SVM Classifier",
          pros: ["Open source", "Audio features extraction", "Research-proven", "Self-hosted"],
          cons: ["Training required", "Moderate accuracy", "Not plug-and-play"],
          privacy: "low-risk",
          recommendation: "Recommended - proven approach"
        },
        {
          name: "Custom TensorFlow Model",
          pros: ["Customizable", "Can train on domain data", "Good accuracy"],
          cons: ["Requires training data", "ML expertise needed", "Development time"],
          privacy: "low-risk",
          recommendation: "Future improvement"
        },
        {
          name: "Azure Voice Analysis",
          pros: ["Ready to use", "Good accuracy"],
          cons: ["Cost", "Privacy concerns", "Limited customization"],
          privacy: "high-risk",
          recommendation: "Avoid for privacy reasons"
        }
      ]
    },
    {
      category: "Phone Number Lookup & Caller ID",
      options: [
        {
          name: "Twilio Lookup API",
          pros: ["Accurate number info", "Carrier data", "International", "Name lookup (paid)"],
          cons: ["Cost: $0.005-0.01/lookup", "Limited free tier", "Only number-based"],
          privacy: "medium-risk",
          recommendation: "Good for phone number enrichment"
        },
        {
          name: "Truecaller API",
          pros: ["Large spam database", "Name lookup", "Community data", "Spam scoring"],
          cons: ["Privacy concerns", "API access limited", "Requires partnership"],
          privacy: "high-risk",
          recommendation: "Consider for spam detection only"
        },
        {
          name: "Numverify",
          pros: ["Number validation", "Carrier info", "Geographic data", "Affordable"],
          cons: ["No name lookup", "Limited data", "Rate limits"],
          privacy: "low-risk",
          recommendation: "Basic validation only"
        },
        {
          name: "Self-built Database + Crowdsourcing",
          pros: ["Full control", "Privacy-friendly", "No API costs", "Custom rules"],
          cons: ["Empty at start", "Requires user contributions", "Accuracy depends on users"],
          privacy: "low-risk",
          recommendation: "Build over time alongside paid APIs"
        }
      ]
    },
    {
      category: "Geolocation Inference",
      options: [
        {
          name: "MaxMind GeoIP2",
          pros: ["IP-based location", "City-level accuracy", "Offline database", "Privacy-friendly"],
          cons: ["VPN affects accuracy", "Paid (from $30/mo)", "IP not always available"],
          privacy: "low-risk",
          recommendation: "Good for IP-based inference"
        },
        {
          name: "Phone Number Prefix Analysis",
          pros: ["Free", "Country/region inference", "Offline", "Privacy-friendly"],
          cons: ["Low accuracy", "Only region-level", "Mobile portability issues"],
          privacy: "low-risk",
          recommendation: "Use as fallback"
        },
        {
          name: "Accent Detection ML Model",
          pros: ["Novel approach", "Privacy-friendly", "Works on voice only"],
          cons: ["Complex", "Lower accuracy", "Research-stage", "Requires training data"],
          privacy: "low-risk",
          recommendation: "Research project - not MVP"
        },
        {
          name: "User Opt-in Location Sharing",
          pros: ["Most accurate", "User consent", "GPS precision"],
          cons: ["Requires user action", "Low adoption likely", "Privacy sensitive"],
          privacy: "medium-risk",
          recommendation: "Offer as optional feature"
        }
      ]
    }
  ];

  const getPrivacyColor = (level: string) => {
    switch (level) {
      case 'low-risk': return 'bg-green-100 text-green-800 border-green-300';
      case 'medium-risk': return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'high-risk': return 'bg-red-100 text-red-800 border-red-300';
      default: return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>ML Approaches & Third-Party APIs</CardTitle>
          <CardDescription>Comprehensive comparison of technologies for each component</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="text-blue-900 mb-2">Legend</h4>
            <div className="flex flex-wrap gap-3 text-sm">
              <div className="flex items-center gap-2">
                <div className="h-6 px-3 rounded border bg-green-100 text-green-800 border-green-300">Low Risk</div>
                <span className="text-slate-600">Self-hosted / Open source</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-6 px-3 rounded border bg-amber-100 text-amber-800 border-amber-300">Medium Risk</div>
                <span className="text-slate-600">Limited third-party exposure</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-6 px-3 rounded border bg-red-100 text-red-800 border-red-300">High Risk</div>
                <span className="text-slate-600">Third-party API / PII sharing</span>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            {approaches.map((category, idx) => (
              <div key={idx}>
                <h3 className="text-slate-900 mb-4 pb-2 border-b-2 border-slate-200">{category.category}</h3>
                <div className="space-y-4">
                  {category.options.map((option, optIdx) => (
                    <div key={optIdx} className="p-4 border-2 rounded-lg hover:border-blue-300 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <h4 className="text-slate-900">{option.name}</h4>
                        <Badge className={getPrivacyColor(option.privacy)}>
                          {option.privacy.replace('-', ' ')}
                        </Badge>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4 mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                            <span className="text-sm text-slate-700">Pros</span>
                          </div>
                          <ul className="space-y-1">
                            {option.pros.map((pro, pIdx) => (
                              <li key={pIdx} className="text-sm text-slate-600 ml-6">{pro}</li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <XCircle className="h-4 w-4 text-red-600" />
                            <span className="text-sm text-slate-700">Cons</span>
                          </div>
                          <ul className="space-y-1">
                            {option.cons.map((con, cIdx) => (
                              <li key={cIdx} className="text-sm text-slate-600 ml-6">{con}</li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-blue-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <span className="text-sm text-blue-900 block mb-1">Recommendation</span>
                            <p className="text-sm text-blue-800">{option.recommendation}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recommended Technology Stack</CardTitle>
          <CardDescription>Optimal combination balancing accuracy, cost, and privacy</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-300 rounded-lg">
              <h4 className="text-green-900 mb-4">Privacy-First Production Stack</h4>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Speech-to-Text</span>
                      <Badge className="bg-green-600">Recommended</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Whisper (self-hosted)</p>
                  </div>

                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Speaker ID</span>
                      <Badge className="bg-green-600">Recommended</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Resemblyzer + Custom DB</p>
                  </div>

                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Language Detection</span>
                      <Badge className="bg-green-600">Recommended</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Meta MMS or Whisper built-in</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Gender/Age</span>
                      <Badge className="bg-green-600">Recommended</Badge>
                    </div>
                    <p className="text-sm text-slate-600">openSMILE + SVM</p>
                  </div>

                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Phone Lookup</span>
                      <Badge className="bg-amber-600">Hybrid</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Twilio + Self-built DB</p>
                  </div>

                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Geolocation</span>
                      <Badge className="bg-green-600">Recommended</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Number prefix + MaxMind IP</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 p-3 bg-green-100 border border-green-300 rounded">
                <p className="text-sm text-green-900">
                  <strong>Why this stack:</strong> Maximizes privacy with self-hosted ML models, minimizes API costs, 
                  provides full data control, and meets GDPR/privacy requirements while maintaining good accuracy.
                </p>
              </div>
            </div>

            <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-300 rounded-lg">
              <h4 className="text-blue-900 mb-4">Quick MVP Stack (Faster to Market)</h4>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Speech-to-Text</span>
                      <Badge variant="outline">MVP</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Google Speech-to-Text</p>
                  </div>

                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Speaker ID</span>
                      <Badge variant="outline">MVP</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Azure Speaker Recognition</p>
                  </div>

                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Language Detection</span>
                      <Badge variant="outline">MVP</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Google (built-in)</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Gender/Age</span>
                      <Badge variant="outline">MVP</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Basic heuristics initially</p>
                  </div>

                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Phone Lookup</span>
                      <Badge variant="outline">MVP</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Twilio Lookup only</p>
                  </div>

                  <div className="p-3 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-900">Geolocation</span>
                      <Badge variant="outline">MVP</Badge>
                    </div>
                    <p className="text-sm text-slate-600">Number prefix only</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 p-3 bg-amber-100 border border-amber-300 rounded">
                <p className="text-sm text-amber-900">
                  <strong>Trade-off:</strong> Faster to launch but higher API costs, privacy concerns, 
                  and vendor lock-in. Suitable for validation phase before investing in self-hosted infrastructure.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Privacy Trade-offs Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded">
              <h4 className="text-red-900 mb-2">High Privacy Risk Approaches</h4>
              <ul className="space-y-1 text-sm text-red-800">
                <li>• Sending voice data to third-party APIs (Google, Azure, AWS)</li>
                <li>• Using Truecaller or similar crowdsourced databases</li>
                <li>• Storing unencrypted audio files</li>
                <li>• Indefinite data retention</li>
                <li>• No user consent mechanisms</li>
              </ul>
            </div>

            <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded">
              <h4 className="text-green-900 mb-2">Low Privacy Risk Approaches</h4>
              <ul className="space-y-1 text-sm text-green-800">
                <li>• Self-hosted ML models (Whisper, Resemblyzer)</li>
                <li>• Client-side encryption before upload</li>
                <li>• Automatic data deletion after processing</li>
                <li>• Explicit user consent for each upload</li>
                <li>• Anonymized voice signatures (hash-based)</li>
                <li>• Optional features with clear privacy notices</li>
              </ul>
            </div>

            <div className="p-4 bg-blue-50 border-l-4 border-blue-500 rounded">
              <h4 className="text-blue-900 mb-2">Recommended Mitigation Strategies</h4>
              <ul className="space-y-1 text-sm text-blue-800">
                <li>• Hybrid approach: Self-host for sensitive processing, APIs for enhancement only</li>
                <li>• Always encrypt audio in transit and at rest</li>
                <li>• Process audio in memory, avoid disk writes when possible</li>
                <li>• Store only voice signatures (embeddings), delete original audio</li>
                <li>• Implement data minimization - collect only necessary metadata</li>
                <li>• Provide user dashboard for data management (view, delete)</li>
                <li>• Regular security audits and penetration testing</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
