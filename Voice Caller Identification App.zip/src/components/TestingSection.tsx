import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { FlaskConical, Target, TrendingUp, AlertCircle } from 'lucide-react';

export function TestingSection() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <FlaskConical className="h-5 w-5 text-blue-600" />
            <CardTitle>Test Data Sources</CardTitle>
          </div>
          <CardDescription>Building comprehensive test datasets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="text-blue-900 mb-3">Public Voice Datasets</h4>
                <div className="space-y-2 text-sm text-blue-800">
                  <div className="p-2 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span>LibriSpeech</span>
                      <Badge variant="outline" className="text-xs">1000 hours</Badge>
                    </div>
                    <p className="text-xs text-blue-700">English audiobooks, clean speech</p>
                  </div>

                  <div className="p-2 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span>Common Voice (Mozilla)</span>
                      <Badge variant="outline" className="text-xs">90+ languages</Badge>
                    </div>
                    <p className="text-xs text-blue-700">Crowdsourced, diverse accents</p>
                  </div>

                  <div className="p-2 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span>VoxCeleb</span>
                      <Badge variant="outline" className="text-xs">7000+ speakers</Badge>
                    </div>
                    <p className="text-xs text-blue-700">Celebrity interviews, multi-language</p>
                  </div>

                  <div className="p-2 bg-white rounded border">
                    <div className="flex items-center justify-between mb-1">
                      <span>TIMIT</span>
                      <Badge variant="outline" className="text-xs">630 speakers</Badge>
                    </div>
                    <p className="text-xs text-blue-700">Phonetically diverse, US English</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="text-green-900 mb-3">Custom Test Data Collection</h4>
                <ul className="space-y-2 text-sm text-green-800">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <div>
                      <strong>Team recordings:</strong> Record 20-30 team members with consent
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <div>
                      <strong>Synthetic voices:</strong> Generate test data with known attributes
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <div>
                      <strong>Edge cases:</strong> Noisy, multi-speaker, accented speech
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <div>
                      <strong>Known spam callers:</strong> Public lists of robocall numbers
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <div>
                      <strong>Beta tester submissions:</strong> Real-world recordings with ground truth
                    </div>
                  </li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <h4 className="text-purple-900 mb-3">Test Scenarios Matrix</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-purple-300">
                      <th className="text-left py-2 text-purple-900">Scenario</th>
                      <th className="text-left py-2 text-purple-900">Audio Quality</th>
                      <th className="text-left py-2 text-purple-900">Duration</th>
                      <th className="text-left py-2 text-purple-900">Language</th>
                      <th className="text-left py-2 text-purple-900">Expected Result</th>
                    </tr>
                  </thead>
                  <tbody className="text-purple-800">
                    <tr className="border-b border-purple-200">
                      <td className="py-2">Clear call, known speaker</td>
                      <td className="py-2">High</td>
                      <td className="py-2">30s</td>
                      <td className="py-2">English</td>
                      <td className="py-2">High confidence match</td>
                    </tr>
                    <tr className="border-b border-purple-200">
                      <td className="py-2">Noisy background</td>
                      <td className="py-2">Low</td>
                      <td className="py-2">45s</td>
                      <td className="py-2">Hindi</td>
                      <td className="py-2">Partial match or quality warning</td>
                    </tr>
                    <tr className="border-b border-purple-200">
                      <td className="py-2">Short clip</td>
                      <td className="py-2">Medium</td>
                      <td className="py-2">5s</td>
                      <td className="py-2">English</td>
                      <td className="py-2">Low confidence</td>
                    </tr>
                    <tr className="border-b border-purple-200">
                      <td className="py-2">Multiple speakers</td>
                      <td className="py-2">High</td>
                      <td className="py-2">60s</td>
                      <td className="py-2">Mixed</td>
                      <td className="py-2">Identify primary speaker</td>
                    </tr>
                    <tr className="border-b border-purple-200">
                      <td className="py-2">Unknown speaker, no DB</td>
                      <td className="py-2">High</td>
                      <td className="py-2">30s</td>
                      <td className="py-2">Spanish</td>
                      <td className="py-2">Language detected, no name</td>
                    </tr>
                    <tr>
                      <td className="py-2">Spam robocall</td>
                      <td className="py-2">High</td>
                      <td className="py-2">20s</td>
                      <td className="py-2">English</td>
                      <td className="py-2">Spam detected</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Target className="h-5 w-5 text-green-600" />
            <CardTitle>Evaluation Metrics</CardTitle>
          </div>
          <CardDescription>Measuring system performance and accuracy</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg">
                <h4 className="text-slate-900 mb-3">Accuracy Metrics</h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Name Identification Accuracy</span>
                      <Badge>Target: 80%+</Badge>
                    </div>
                    <p className="text-xs text-slate-600">% of correctly identified names (vs ground truth)</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Language Detection Accuracy</span>
                      <Badge>Target: 95%+</Badge>
                    </div>
                    <p className="text-xs text-slate-600">% of correctly identified languages</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Gender Classification Accuracy</span>
                      <Badge>Target: 85%+</Badge>
                    </div>
                    <p className="text-xs text-slate-600">% of correctly identified genders</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Spam Detection Accuracy</span>
                      <Badge>Target: 90%+</Badge>
                    </div>
                    <p className="text-xs text-slate-600">True positives + true negatives</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Voice Signature Match Rate</span>
                      <Badge>Target: 75%+</Badge>
                    </div>
                    <p className="text-xs text-slate-600">Same speaker correctly matched</p>
                  </div>
                </div>
              </div>

              <div className="p-4 border rounded-lg">
                <h4 className="text-slate-900 mb-3">Performance Metrics</h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Processing Time (30s audio)</span>
                      <Badge>Target: &lt;15s</Badge>
                    </div>
                    <p className="text-xs text-slate-600">End-to-end processing latency</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">API Response Time</span>
                      <Badge>Target: &lt;500ms</Badge>
                    </div>
                    <p className="text-xs text-slate-600">P95 response time for API calls</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Upload Success Rate</span>
                      <Badge>Target: 99%+</Badge>
                    </div>
                    <p className="text-xs text-slate-600">% of uploads that complete successfully</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Processing Success Rate</span>
                      <Badge>Target: 85%+</Badge>
                    </div>
                    <p className="text-xs text-slate-600">% of uploads that produce results</p>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-700">Concurrent Processing Capacity</span>
                      <Badge>Target: 100+</Badge>
                    </div>
                    <p className="text-xs text-slate-600">Simultaneous analyses without degradation</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="text-slate-900 mb-3">Evaluation Calculation Formulas</h4>
              <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`// Name Identification Accuracy
accuracy = correct_identifications / total_with_ground_truth

// Precision & Recall for Name Matches
precision = true_positives / (true_positives + false_positives)
recall = true_positives / (true_positives + false_negatives)
f1_score = 2 * (precision * recall) / (precision + recall)

// Mean Absolute Error for Confidence Scores
mae = mean(abs(predicted_confidence - actual_correctness))

// False Positive Rate (Spam Detection)
fpr = false_positives / (false_positives + true_negatives)

// Voice Signature Similarity Distribution
// Should see: high similarity (>0.8) for same speaker
//            low similarity (<0.5) for different speakers
same_speaker_similarity = mean([sim for (a,b) if same_speaker(a,b)])
diff_speaker_similarity = mean([sim for (a,b) if !same_speaker(a,b)])
separation_score = same_speaker_similarity - diff_speaker_similarity

// User Satisfaction Metrics
nps = (promoters - detractors) / total_responses * 100
csat = satisfied_users / total_respondents * 100`}
              </pre>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-purple-600" />
            <CardTitle>User Feedback System</CardTitle>
          </div>
          <CardDescription>Collecting and incorporating user feedback for continuous improvement</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <h4 className="text-purple-900 mb-3">Feedback Collection Points</h4>
                <ul className="space-y-2 text-sm text-purple-800">
                  <li className="flex items-start gap-2">
                    <span className="text-purple-600">1.</span>
                    <div>
                      <strong>Results Page:</strong> "Was this information accurate?" with thumbs up/down
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-600">2.</span>
                    <div>
                      <strong>Detailed Feedback Form:</strong> Rate each field (name, location, language, etc.)
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-600">3.</span>
                    <div>
                      <strong>Corrections:</strong> Allow users to provide correct information
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-600">4.</span>
                    <div>
                      <strong>Spam Reporting:</strong> Dedicated "Report as Spam" button
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-600">5.</span>
                    <div>
                      <strong>In-app Surveys:</strong> Periodic NPS and satisfaction surveys
                    </div>
                  </li>
                </ul>
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="text-blue-900 mb-3">Feedback UI Example</h4>
                <div className="p-3 bg-white rounded border space-y-3">
                  <div>
                    <p className="text-sm text-slate-900 mb-2">How accurate was this analysis?</p>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map(star => (
                        <div key={star} className="h-8 w-8 border rounded flex items-center justify-center cursor-pointer hover:bg-yellow-50">
                          ★
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-3 border-t">
                    <p className="text-sm text-slate-900 mb-2">Which information was incorrect?</p>
                    <div className="space-y-1 text-xs">
                      <label className="flex items-center gap-2">
                        <input type="checkbox" />
                        <span>Name</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" />
                        <span>Location</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" />
                        <span>Language</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" />
                        <span>Gender</span>
                      </label>
                    </div>
                  </div>

                  <div className="pt-3 border-t">
                    <p className="text-sm text-slate-900 mb-2">Provide corrections (optional):</p>
                    <input 
                      type="text" 
                      placeholder="Correct name..."
                      className="w-full p-2 border rounded text-xs"
                    />
                  </div>

                  <button className="w-full bg-blue-600 text-white py-2 rounded text-sm">
                    Submit Feedback
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <h4 className="text-green-900 mb-3">Incentivizing Quality Feedback</h4>
              <ul className="space-y-2 text-sm text-green-800">
                <li className="flex items-start gap-2">
                  <span className="text-green-600">•</span>
                  <div>
                    <strong>Credits/Points:</strong> Earn 1 free analysis credit for every 5 quality feedback submissions
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600">•</span>
                  <div>
                    <strong>Accuracy Badge:</strong> Users who provide helpful corrections get "Verified Contributor" badge
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600">•</span>
                  <div>
                    <strong>Transparency:</strong> Show users how their feedback improves the system ("Your feedback helped improve accuracy by 2%")
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600">•</span>
                  <div>
                    <strong>Priority Support:</strong> Active feedback providers get priority customer support
                  </div>
                </li>
              </ul>
            </div>

            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <h4 className="text-amber-900 mb-3">Feedback Processing Pipeline</h4>
              <div className="space-y-2 text-sm text-amber-800">
                <div className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs">1</div>
                  <div>
                    <strong>Collection:</strong> Store feedback in database with timestamp and user ID
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs">2</div>
                  <div>
                    <strong>Validation:</strong> Flag obviously invalid feedback (bots, spam)
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs">3</div>
                  <div>
                    <strong>Aggregation:</strong> Weekly analysis of feedback trends
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs">4</div>
                  <div>
                    <strong>Model Retraining:</strong> Use corrected data to improve ML models
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs">5</div>
                  <div>
                    <strong>Database Updates:</strong> Add confirmed corrections to caller database
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs">6</div>
                  <div>
                    <strong>Notification:</strong> Thank users and show impact of their contribution
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <CardTitle>Reporting Wrong Results</CardTitle>
          </div>
          <CardDescription>Handling and learning from errors</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <h4 className="text-red-900 mb-3">Error Categories</h4>
              <div className="grid md:grid-cols-2 gap-3">
                <div className="p-3 bg-white rounded border">
                  <h5 className="text-sm text-red-900 mb-1">Critical Errors</h5>
                  <ul className="text-xs text-red-800 space-y-1">
                    <li>• Wrong person identified (privacy violation)</li>
                    <li>• False spam classification</li>
                    <li>• Completely wrong all information</li>
                  </ul>
                  <p className="text-xs text-red-700 mt-2"><strong>Action:</strong> Immediate review, remove from database</p>
                </div>

                <div className="p-3 bg-white rounded border">
                  <h5 className="text-sm text-amber-900 mb-1">Minor Errors</h5>
                  <ul className="text-xs text-amber-800 space-y-1">
                    <li>• Location slightly off (wrong city, right region)</li>
                    <li>• Gender misclassified</li>
                    <li>• Language variant wrong (Hindi vs Punjabi)</li>
                  </ul>
                  <p className="text-xs text-amber-700 mt-2"><strong>Action:</strong> Update confidence scores, improve models</p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="text-blue-900 mb-3">Error Response Flow</h4>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 h-8 w-8 rounded bg-blue-600 text-white flex items-center justify-center">1</div>
                  <div>
                    <h5 className="text-sm text-blue-900">User Reports Error</h5>
                    <p className="text-xs text-blue-800">User clicks "Report Wrong" button, fills form with details</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 h-8 w-8 rounded bg-blue-600 text-white flex items-center justify-center">2</div>
                  <div>
                    <h5 className="text-sm text-blue-900">Automatic Triage</h5>
                    <p className="text-xs text-blue-800">System categorizes error severity based on field and confidence gap</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 h-8 w-8 rounded bg-blue-600 text-white flex items-center justify-center">3</div>
                  <div>
                    <h5 className="text-sm text-blue-900">Immediate Action (if critical)</h5>
                    <p className="text-xs text-blue-800">Hide result from user, flag for manual review, notify team</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 h-8 w-8 rounded bg-blue-600 text-white flex items-center justify-center">4</div>
                  <div>
                    <h5 className="text-sm text-blue-900">Investigation</h5>
                    <p className="text-xs text-blue-800">Team reviews audio, checks processing logs, identifies root cause</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 h-8 w-8 rounded bg-blue-600 text-white flex items-center justify-center">5</div>
                  <div>
                    <h5 className="text-sm text-blue-900">Fix & Learn</h5>
                    <p className="text-xs text-blue-800">Update models, adjust thresholds, add to training data if applicable</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 h-8 w-8 rounded bg-blue-600 text-white flex items-center justify-center">6</div>
                  <div>
                    <h5 className="text-sm text-blue-900">User Notification</h5>
                    <p className="text-xs text-blue-800">Thank user, explain what was fixed, offer compensation if appropriate</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <h4 className="text-purple-900 mb-3">Error Rate Monitoring</h4>
              <div className="grid md:grid-cols-3 gap-3">
                <div className="p-3 bg-white rounded border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-purple-900">Daily Error Rate</span>
                    <Badge className="bg-green-600">Normal</Badge>
                  </div>
                  <p className="text-xs text-purple-800">Alert if &gt;5% of analyses reported as wrong</p>
                </div>

                <div className="p-3 bg-white rounded border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-purple-900">Field-Specific Errors</span>
                    <Badge className="bg-amber-600">Warning</Badge>
                  </div>
                  <p className="text-xs text-purple-800">Track which fields have highest error rates</p>
                </div>

                <div className="p-3 bg-white rounded border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-purple-900">Trend Analysis</span>
                    <Badge variant="outline">Monitor</Badge>
                  </div>
                  <p className="text-xs text-purple-800">Is accuracy improving or degrading over time?</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>A/B Testing Framework</CardTitle>
          <CardDescription>Experimental features and continuous optimization</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="text-slate-900 mb-3">Example A/B Tests</h4>
              <div className="space-y-3">
                <div className="p-3 border rounded">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="text-slate-900">Test: Confidence Threshold</h5>
                    <Badge>Active</Badge>
                  </div>
                  <div className="grid md:grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-slate-700 mb-1">Variant A (Control):</p>
                      <p className="text-slate-600">Show results if confidence ≥ 0.50</p>
                    </div>
                    <div>
                      <p className="text-slate-700 mb-1">Variant B:</p>
                      <p className="text-slate-600">Show results if confidence ≥ 0.65</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-2">Metric: User satisfaction score, error report rate</p>
                </div>

                <div className="p-3 border rounded">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="text-slate-900">Test: UI Layout</h5>
                    <Badge variant="outline">Planned</Badge>
                  </div>
                  <div className="grid md:grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-slate-700 mb-1">Variant A (Control):</p>
                      <p className="text-slate-600">Show all fields immediately</p>
                    </div>
                    <div>
                      <p className="text-slate-700 mb-1">Variant B:</p>
                      <p className="text-slate-600">Expandable sections by category</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-2">Metric: Time to find information, comprehension</p>
                </div>

                <div className="p-3 border rounded">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="text-slate-900">Test: Processing Approach</h5>
                    <Badge variant="outline">Future</Badge>
                  </div>
                  <div className="grid md:grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-slate-700 mb-1">Variant A (Control):</p>
                      <p className="text-slate-600">All analyses server-side</p>
                    </div>
                    <div>
                      <p className="text-slate-700 mb-1">Variant B:</p>
                      <p className="text-slate-600">Language detection on-device first</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-2">Metric: Processing time, battery usage, privacy perception</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}