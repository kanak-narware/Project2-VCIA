import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';

export function APISection() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>API Endpoints</CardTitle>
          <CardDescription>Complete REST API specification</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="text-blue-900 mb-2">Base URL</h4>
              <code className="text-sm text-blue-800">https://api.voicecallerid.com/v1</code>
              <p className="text-sm text-blue-800 mt-2">All requests must include authentication token in header:</p>
              <code className="text-sm text-blue-800">Authorization: Bearer &lt;token&gt;</code>
            </div>

            <Tabs defaultValue="upload">
              <TabsList className="grid grid-cols-2 md:grid-cols-4">
                <TabsTrigger value="upload">Upload</TabsTrigger>
                <TabsTrigger value="analyze">Analyze</TabsTrigger>
                <TabsTrigger value="results">Results</TabsTrigger>
                <TabsTrigger value="user">User</TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="space-y-4">
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge className="bg-blue-600">POST</Badge>
                      <code className="text-sm">/upload/init</code>
                    </div>
                    <p className="text-sm text-slate-600 mb-3">Initialize upload and get presigned URL</p>
                    
                    <div className="space-y-3">
                      <div>
                        <h5 className="text-sm text-slate-900 mb-2">Request Body:</h5>
                        <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "filename": "call_recording.mp3",
  "file_size": 15728640,
  "content_type": "audio/mpeg",
  "metadata": {
    "caller_number": "+91-9876543210", // optional
    "timestamp": "2025-10-24T10:30:00Z",
    "consent_version": "1.0"
  }
}`}
                        </pre>
                      </div>

                      <div>
                        <h5 className="text-sm text-slate-900 mb-2">Response (200 OK):</h5>
                        <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "upload_id": "upl_abc123",
  "presigned_url": "https://s3.amazonaws.com/bucket/...",
  "expires_at": "2025-10-24T11:00:00Z",
  "upload_fields": {
    "key": "uploads/usr_123/upl_abc123.mp3",
    "x-amz-algorithm": "AWS4-HMAC-SHA256",
    "x-amz-credential": "...",
    "x-amz-date": "...",
    "policy": "...",
    "x-amz-signature": "..."
  }
}`}
                        </pre>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge className="bg-green-600">POST</Badge>
                      <code className="text-sm">/upload/complete</code>
                    </div>
                    <p className="text-sm text-slate-600 mb-3">Confirm upload and start processing</p>
                    
                    <div className="space-y-3">
                      <div>
                        <h5 className="text-sm text-slate-900 mb-2">Request Body:</h5>
                        <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "upload_id": "upl_abc123",
  "metadata": {
    "user_id": "usr_123",
    "consent": true,
    "retention_days": 7
  }
}`}
                        </pre>
                      </div>

                      <div>
                        <h5 className="text-sm text-slate-900 mb-2">Response (202 Accepted):</h5>
                        <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "analysis_id": "ana_xyz789",
  "status": "queued",
  "estimated_time_seconds": 45,
  "queue_position": 3
}`}
                        </pre>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="analyze" className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-purple-600">GET</Badge>
                    <code className="text-sm">/analysis/:analysis_id/status</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">Check processing status</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Response (200 OK):</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "analysis_id": "ana_xyz789",
  "status": "processing", // queued | processing | completed | failed
  "progress": 0.67,
  "current_stage": "voice_analysis",
  "stages": {
    "upload": "completed",
    "audio_preprocessing": "completed",
    "transcription": "completed",
    "voice_analysis": "processing",
    "database_matching": "pending",
    "result_aggregation": "pending"
  },
  "estimated_completion": "2025-10-24T10:31:00Z"
}`}
                      </pre>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-red-600">DELETE</Badge>
                    <code className="text-sm">/analysis/:analysis_id/cancel</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">Cancel ongoing analysis</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Response (200 OK):</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "analysis_id": "ana_xyz789",
  "status": "cancelled",
  "refund_credits": 1
}`}
                      </pre>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="results" className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-green-600">GET</Badge>
                    <code className="text-sm">/analysis/:analysis_id/results</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">Get analysis results (see Data Formats tab for full response)</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Query Parameters:</h5>
                      <ul className="text-xs text-slate-600 space-y-1">
                        <li>• <code>include_audio</code> (boolean) - Include original audio URL (default: false)</li>
                        <li>• <code>include_transcription</code> (boolean) - Include full transcription (default: true)</li>
                        <li>• <code>include_similar</code> (boolean) - Include similar matches (default: true)</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-blue-600">GET</Badge>
                    <code className="text-sm">/analysis</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">List all analyses for current user</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Query Parameters:</h5>
                      <ul className="text-xs text-slate-600 space-y-1">
                        <li>• <code>limit</code> (integer) - Results per page (default: 20, max: 100)</li>
                        <li>• <code>offset</code> (integer) - Pagination offset (default: 0)</li>
                        <li>• <code>status</code> (string) - Filter by status (completed, failed, processing)</li>
                        <li>• <code>from_date</code> (ISO 8601) - Filter from date</li>
                        <li>• <code>to_date</code> (ISO 8601) - Filter to date</li>
                      </ul>
                    </div>

                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Response (200 OK):</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "results": [
    {
      "analysis_id": "ana_xyz789",
      "timestamp": "2025-10-24T10:30:00Z",
      "status": "completed",
      "caller_name": "John Doe",
      "confidence": 0.87,
      "is_spam": false
    },
    ...
  ],
  "total": 145,
  "limit": 20,
  "offset": 0,
  "has_more": true
}`}
                      </pre>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-red-600">DELETE</Badge>
                    <code className="text-sm">/analysis/:analysis_id</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">Delete analysis and all associated data</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Response (200 OK):</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "deleted": true,
  "analysis_id": "ana_xyz789",
  "items_deleted": {
    "audio_file": true,
    "transcription": true,
    "voice_signature": true,
    "metadata": true
  }
}`}
                      </pre>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-amber-600">POST</Badge>
                    <code className="text-sm">/analysis/:analysis_id/feedback</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">Submit feedback on analysis accuracy</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Request Body:</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "rating": 4, // 1-5 stars
  "accuracy": {
    "name": "correct", // correct | incorrect | unknown
    "location": "partially_correct",
    "language": "correct",
    "gender": "incorrect"
  },
  "is_spam": true,
  "comments": "Name was correct but location was wrong",
  "corrected_data": {
    "name": "Jane Doe",
    "location": "Delhi, India"
  }
}`}
                      </pre>
                    </div>

                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Response (200 OK):</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "feedback_id": "fb_123",
  "thank_you": "Thanks for helping improve our accuracy!",
  "credits_earned": 1
}`}
                      </pre>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="user" className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-green-600">GET</Badge>
                    <code className="text-sm">/user/profile</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">Get current user profile and usage stats</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Response (200 OK):</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "user_id": "usr_123",
  "email": "user@example.com",
  "tier": "premium",
  "usage": {
    "analyses_today": 7,
    "analyses_month": 143,
    "limit_daily": 100,
    "limit_monthly": -1,
    "credits_remaining": 93
  },
  "created_at": "2025-01-01T00:00:00Z"
}`}
                      </pre>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-blue-600">GET</Badge>
                    <code className="text-sm">/user/data-export</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">Export all user data (GDPR compliance)</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Response (202 Accepted):</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "export_id": "exp_abc123",
  "status": "processing",
  "estimated_completion": "2025-10-24T11:00:00Z",
  "download_url": null // Available when status = "completed"
}`}
                      </pre>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-red-600">DELETE</Badge>
                    <code className="text-sm">/user/account</code>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">Delete account and all associated data (GDPR Right to Erasure)</p>
                  
                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Request Body:</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "confirmation": "DELETE MY ACCOUNT",
  "password": "user_password"
}`}
                      </pre>
                    </div>

                    <div>
                      <h5 className="text-sm text-slate-900 mb-2">Response (200 OK):</h5>
                      <pre className="text-xs bg-slate-900 text-slate-100 p-3 rounded overflow-x-auto">
{`{
  "deleted": true,
  "deletion_id": "del_xyz789",
  "scheduled_completion": "2025-10-31T00:00:00Z",
  "message": "Your account and all data will be permanently deleted within 30 days"
}`}
                      </pre>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Processing Pipeline Pseudocode</CardTitle>
          <CardDescription>Core processing logic implementation</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-slate-50 rounded-lg">
            <h4 className="text-slate-900 mb-3">Main Processing Pipeline</h4>
            <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`async function processAudioAnalysis(uploadId, metadata) {
  const analysisId = generateAnalysisId();
  
  try {
    // Update status
    await updateAnalysisStatus(analysisId, 'processing', 'audio_preprocessing');
    
    // 1. Download and decrypt audio
    const audioFile = await downloadFromS3(uploadId);
    const decryptedAudio = await decrypt(audioFile, metadata.encryptionKey);
    
    // 2. Audio preprocessing
    const processedAudio = await preprocessAudio(decryptedAudio, {
      normalize: true,
      noiseReduction: true,
      format: 'wav',
      sampleRate: 16000
    });
    
    // 3. Quality check
    const qualityMetrics = await assessAudioQuality(processedAudio);
    if (qualityMetrics.snr < 10) {
      throw new Error('AUDIO_QUALITY_TOO_LOW');
    }
    
    // 4. Parallel analysis tasks
    const [
      transcription,
      voiceFeatures,
      languageDetection,
      speakerDiarization
    ] = await Promise.all([
      transcribeAudio(processedAudio),
      extractVoiceFeatures(processedAudio),
      detectLanguage(processedAudio),
      diarizeSpeakers(processedAudio)
    ]);
    
    await updateAnalysisStatus(analysisId, 'processing', 'database_matching');
    
    // 5. Database matching
    const voiceSignature = await generateVoiceSignature(voiceFeatures);
    const [
      voiceMatches,
      phoneMatches,
      spamCheck,
      entityExtraction
    ] = await Promise.all([
      findSimilarVoiceSignatures(voiceSignature),
      lookupPhoneNumber(metadata.callerNumber),
      checkSpamDatabases(metadata.callerNumber, transcription.text),
      extractEntities(transcription.text)
    ]);
    
    await updateAnalysisStatus(analysisId, 'processing', 'result_aggregation');
    
    // 6. Gender and age estimation
    const demographics = await estimateDemographics(voiceFeatures);
    
    // 7. Location inference
    const location = await inferLocation({
      phoneNumber: metadata.callerNumber,
      ipAddress: metadata.ipAddress,
      accent: languageDetection.accent
    });
    
    // 8. Aggregate results
    const results = {
      analysis_id: analysisId,
      timestamp: new Date().toISOString(),
      caller_info: {
        name: aggregateNameData(voiceMatches, phoneMatches, entityExtraction),
        location: location,
        phone_number: phoneMatches
      },
      voice_analysis: {
        language: languageDetection,
        gender: demographics.gender,
        age_estimate: demographics.age,
        speaker_id: voiceSignature.id,
        voice_signature_hash: hash(voiceSignature.embedding)
      },
      audio_quality: qualityMetrics,
      transcription: transcription,
      spam_analysis: spamCheck,
      similar_matches: voiceMatches.slice(0, 5),
      confidence_overall: calculateOverallConfidence(results)
    };
    
    // 9. Store results
    await storeAnalysisResults(analysisId, results);
    
    // 10. Store voice signature for future matching
    await storeVoiceSignature(voiceSignature, metadata.userId);
    
    // 11. Schedule audio deletion
    await scheduleAudioDeletion(uploadId, metadata.retentionDays || 7);
    
    // 12. Update status to completed
    await updateAnalysisStatus(analysisId, 'completed');
    
    // 13. Send notification
    await sendPushNotification(metadata.userId, {
      title: 'Analysis Complete',
      body: \`Caller identified: \${results.caller_info.name.value || 'Unknown'}\`,
      analysis_id: analysisId
    });
    
    return results;
    
  } catch (error) {
    await updateAnalysisStatus(analysisId, 'failed', error.message);
    await logError(analysisId, error);
    throw error;
  }
}

// Helper function: Calculate overall confidence
function calculateOverallConfidence(results) {
  const weights = {
    name: 0.30,
    voice_match: 0.25,
    phone_lookup: 0.20,
    language: 0.10,
    location: 0.10,
    spam_score: 0.05
  };
  
  let totalWeight = 0;
  let weightedSum = 0;
  
  for (const [field, weight] of Object.entries(weights)) {
    const data = getFieldData(results, field);
    if (data && data.confidence) {
      weightedSum += data.confidence * weight;
      totalWeight += weight;
    }
  }
  
  return totalWeight > 0 ? weightedSum / totalWeight : 0;
}

// Helper function: Aggregate name data from multiple sources
function aggregateNameData(voiceMatches, phoneMatches, entities) {
  const nameCandidates = [];
  
  // Voice match names
  if (voiceMatches && voiceMatches.length > 0) {
    nameCandidates.push({
      value: voiceMatches[0].name,
      confidence: voiceMatches[0].similarity,
      source: 'voice_signature_match'
    });
  }
  
  // Phone lookup name
  if (phoneMatches && phoneMatches.name) {
    nameCandidates.push({
      value: phoneMatches.name,
      confidence: phoneMatches.confidence || 0.8,
      source: 'phone_number_lookup'
    });
  }
  
  // Extracted from transcription
  const nameEntities = entities.filter(e => e.type === 'person');
  if (nameEntities.length > 0) {
    nameCandidates.push({
      value: nameEntities[0].value,
      confidence: nameEntities[0].confidence,
      source: 'transcription_entity'
    });
  }
  
  // Return highest confidence name
  if (nameCandidates.length === 0) return null;
  
  nameCandidates.sort((a, b) => b.confidence - a.confidence);
  return nameCandidates[0];
}`}
            </pre>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg">
            <h4 className="text-slate-900 mb-3">Voice Signature Matching</h4>
            <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`async function findSimilarVoiceSignatures(newSignature) {
  // newSignature.embedding is a 256-dimensional vector
  
  // Option 1: Using pgvector (PostgreSQL extension)
  const pgResults = await db.query(\`
    SELECT 
      speaker_id,
      name,
      1 - (embedding <=> $1::vector) AS similarity
    FROM voice_signatures
    WHERE 1 - (embedding <=> $1::vector) > 0.7
    ORDER BY embedding <=> $1::vector
    LIMIT 10
  \`, [newSignature.embedding]);
  
  // Option 2: Using Pinecone/Weaviate vector database
  const vectorDBResults = await vectorDB.query({
    vector: newSignature.embedding,
    topK: 10,
    scoreThreshold: 0.7
  });
  
  // Transform results
  return pgResults.rows.map(row => ({
    speaker_id: row.speaker_id,
    name: row.name,
    similarity_score: row.similarity,
    match_reason: 'voice_similarity'
  }));
}

// Generate voice signature using Resemblyzer or similar
async function generateVoiceSignature(voiceFeatures) {
  // Extract speaker embedding (256-d vector)
  const embedding = await resemblyzer.extractEmbedding(voiceFeatures);
  
  // Generate unique speaker ID
  const speakerId = \`spk_\${hash(embedding).substring(0, 12)}\`;
  
  // Hash the full embedding for privacy
  const signatureHash = sha256(embedding);
  
  return {
    id: speakerId,
    embedding: embedding,
    hash: signatureHash,
    created_at: new Date().toISOString()
  };
}`}
            </pre>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>WebSocket API (Optional - Real-time Updates)</CardTitle>
          <CardDescription>For live processing status updates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <h4 className="text-purple-900 mb-3">WebSocket Connection</h4>
            <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`// Client-side connection
const ws = new WebSocket('wss://api.voicecallerid.com/v1/ws');

ws.onopen = () => {
  // Subscribe to analysis updates
  ws.send(JSON.stringify({
    type: 'subscribe',
    analysis_id: 'ana_xyz789',
    auth_token: 'bearer_token_here'
  }));
};

ws.onmessage = (event) => {
  const update = JSON.parse(event.data);
  
  switch (update.type) {
    case 'status_update':
      console.log('Status:', update.status);
      console.log('Progress:', update.progress);
      break;
      
    case 'stage_complete':
      console.log('Completed:', update.stage);
      break;
      
    case 'analysis_complete':
      console.log('Results:', update.results);
      break;
      
    case 'error':
      console.error('Error:', update.error);
      break;
  }
};

// Server-side messages
{
  "type": "status_update",
  "analysis_id": "ana_xyz789",
  "status": "processing",
  "progress": 0.45,
  "current_stage": "transcription"
}

{
  "type": "stage_complete",
  "analysis_id": "ana_xyz789",
  "stage": "transcription",
  "result_preview": {
    "text": "Hello, this is John calling from...",
    "language": "en-IN"
  }
}

{
  "type": "analysis_complete",
  "analysis_id": "ana_xyz789",
  "results": { /* full results object */ }
}`}
            </pre>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}