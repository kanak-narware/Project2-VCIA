import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { AlertTriangle, Target, Users, Smartphone } from 'lucide-react';

export function OverviewSection() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Executive Summary</CardTitle>
          <CardDescription>Voice Caller Identification Mobile Application</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="prose max-w-none">
            <p>
              The Voice Caller ID app is a mobile application that allows users to submit recorded voice clips 
              (such as unknown calls) and receive identification information about the caller. The system leverages 
              advanced speech processing, machine learning, and public data sources to provide:
            </p>
            <ul className="space-y-2 mt-4">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Caller Name:</strong> Likely identity if publicly available in databases</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Location:</strong> Possible geographic location based on inference or opt-in sharing</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Voice Metadata:</strong> Language, gender estimate, audio quality metrics</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Confidence Scores:</strong> Reliability indicators for each data point</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Alert className="border-amber-200 bg-amber-50">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-900">
          <strong>Important Privacy Note:</strong> This application handles sensitive personal data. 
          Strict privacy controls, consent mechanisms, and compliance with GDPR and India IT Rules 2021 
          are mandatory. The system is designed with privacy-by-design principles.
        </AlertDescription>
      </Alert>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-blue-600" />
              <CardTitle>Primary Use Cases</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 bg-slate-50 rounded-lg">
              <h4 className="text-slate-900 mb-1">Unknown Call Identification</h4>
              <p className="text-sm text-slate-600">
                Users receive calls from unknown numbers and want to identify the caller before responding
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg">
              <h4 className="text-slate-900 mb-1">Spam/Scam Detection</h4>
              <p className="text-sm text-slate-600">
                Cross-reference voice patterns against known spam caller databases
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg">
              <h4 className="text-slate-900 mb-1">Community Reporting</h4>
              <p className="text-sm text-slate-600">
                Build a crowdsourced database of caller information with user feedback
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-purple-600" />
              <CardTitle>Target Audience</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">Primary</Badge>
              <div>
                <p className="text-slate-900">Individuals receiving frequent unknown calls</p>
                <p className="text-sm text-slate-600">Personal safety and spam prevention</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">Secondary</Badge>
              <div>
                <p className="text-slate-900">Small businesses</p>
                <p className="text-sm text-slate-600">Customer call verification and logging</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-1">Geographic</Badge>
              <div>
                <p className="text-slate-900">India, US, EU markets initially</p>
                <p className="text-sm text-slate-600">With region-specific compliance</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Smartphone className="h-5 w-5 text-green-600" />
            <CardTitle>Key Differentiators</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 border border-green-200 bg-green-50 rounded-lg">
              <h4 className="text-green-900 mb-2">Voice-Based ID</h4>
              <p className="text-sm text-green-800">
                Unlike number-only apps, analyzes actual voice characteristics for richer identification
              </p>
            </div>
            <div className="p-4 border border-blue-200 bg-blue-50 rounded-lg">
              <h4 className="text-blue-900 mb-2">Multi-Modal Analysis</h4>
              <p className="text-sm text-blue-800">
                Combines speech-to-text, voice biometrics, language detection, and metadata analysis
              </p>
            </div>
            <div className="p-4 border border-purple-200 bg-purple-50 rounded-lg">
              <h4 className="text-purple-900 mb-2">Privacy-First</h4>
              <p className="text-sm text-purple-800">
                Optional processing, automatic deletion, encrypted storage, and transparent consent
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
