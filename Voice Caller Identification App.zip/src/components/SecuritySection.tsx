import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Shield, Lock, Eye, FileText, AlertTriangle, CheckCircle } from 'lucide-react';

export function SecuritySection() {
  return (
    <div className="space-y-6">
      <Alert className="border-red-200 bg-red-50">
        <AlertTriangle className="h-4 w-4 text-red-600" />
        <AlertDescription className="text-red-900">
          <strong>Critical:</strong> This application handles highly sensitive biometric data (voice recordings). 
          Security and privacy must be treated as top priority, not an afterthought. Non-compliance can result 
          in severe legal penalties and permanent reputation damage.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-blue-600" />
            <CardTitle>Data Encryption</CardTitle>
          </div>
          <CardDescription>End-to-end encryption strategy</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 border-2 border-blue-200 rounded-lg bg-blue-50">
              <h4 className="text-blue-900 mb-3">In Transit</h4>
              <ul className="space-y-2 text-sm text-blue-800">
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>TLS 1.3 minimum</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Certificate pinning (mobile)</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>HTTPS only, no HTTP fallback</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Perfect Forward Secrecy (PFS)</span>
                </li>
              </ul>
            </div>

            <div className="p-4 border-2 border-green-200 rounded-lg bg-green-50">
              <h4 className="text-green-900 mb-3">At Rest</h4>
              <ul className="space-y-2 text-sm text-green-800">
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>AES-256 encryption</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>S3 server-side encryption (SSE-KMS)</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Database encryption (PostgreSQL pgcrypto)</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Separate encryption keys per user</span>
                </li>
              </ul>
            </div>

            <div className="p-4 border-2 border-purple-200 rounded-lg bg-purple-50">
              <h4 className="text-purple-900 mb-3">Client-Side</h4>
              <ul className="space-y-2 text-sm text-purple-800">
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Optional: Encrypt before upload</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>User-specific encryption keys</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Secure key storage (Keychain/Keystore)</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>No keys in app code/memory dumps</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg">
            <h4 className="text-slate-900 mb-3">Encryption Implementation Example</h4>
            <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`// Client-side encryption (optional but recommended)
import { AES, enc } from 'crypto-js';

async function uploadEncryptedAudio(audioBlob, userKey) {
  // Generate per-file key
  const fileKey = generateRandomKey();
  
  // Encrypt audio with file key
  const encrypted = AES.encrypt(audioBlob, fileKey);
  
  // Encrypt file key with user key (stored securely)
  const encryptedKey = AES.encrypt(fileKey, userKey);
  
  // Upload to server
  await upload({
    encrypted_audio: encrypted,
    encrypted_key: encryptedKey,
    encryption_version: 'AES-256-CBC-v1'
  });
}

// Server-side S3 encryption configuration
{
  "Rules": [
    {
      "ApplyServerSideEncryptionByDefault": {
        "SSEAlgorithm": "aws:kms",
        "KMSMasterKeyID": "arn:aws:kms:region:account:key/key-id"
      },
      "BucketKeyEnabled": true
    }
  ]
}`}
            </pre>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-green-600" />
            <CardTitle>Consent Management</CardTitle>
          </div>
          <CardDescription>Explicit, granular, and revocable consent</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <h4 className="text-green-900 mb-3">Required Consent Types</h4>
            <div className="space-y-3">
              <div className="p-3 bg-white border rounded">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Audio Processing Consent</span>
                  <Badge className="bg-red-600">Required</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  "I consent to [App Name] processing this voice recording for caller identification purposes."
                </p>
              </div>

              <div className="p-3 bg-white border rounded">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Voice Signature Storage</span>
                  <Badge className="bg-red-600">Required</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  "I consent to storing a mathematical signature of this voice for future matching (original audio deleted after 7 days)."
                </p>
              </div>

              <div className="p-3 bg-white border rounded">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Third-Party API Usage</span>
                  <Badge className="bg-amber-600">Conditional</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  "I consent to sending anonymized audio data to trusted partners (Google, Azure) for enhanced analysis." (Only if using third-party APIs)
                </p>
              </div>

              <div className="p-3 bg-white border rounded">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Location Sharing</span>
                  <Badge variant="outline">Optional</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  "I consent to sharing my device location to improve caller location accuracy."
                </p>
              </div>

              <div className="p-3 bg-white border rounded">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Community Database Contribution</span>
                  <Badge variant="outline">Optional</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  "I consent to contributing anonymized caller information to help other users identify spam/scam calls."
                </p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="text-blue-900 mb-3">Consent Management Features</h4>
            <ul className="space-y-2 text-sm text-blue-800">
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5 text-blue-600" />
                <span>Granular consent per feature (not all-or-nothing)</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5 text-blue-600" />
                <span>Consent required before each upload (not just once at signup)</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5 text-blue-600" />
                <span>Easy withdrawal - user can revoke consent anytime</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5 text-blue-600" />
                <span>Consent version tracking (update users when policy changes)</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5 text-blue-600" />
                <span>Audit log of all consent actions with timestamps</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5 text-blue-600" />
                <span>Clear, plain language explanations (no legalese)</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-purple-600" />
            <CardTitle>GDPR Compliance</CardTitle>
          </div>
          <CardDescription>European Union General Data Protection Regulation</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 border rounded-lg">
              <h4 className="text-slate-900 mb-3">Required GDPR Features</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">•</span>
                  <div>
                    <strong>Right to Access:</strong> Users can download all their data in machine-readable format (JSON export)
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">•</span>
                  <div>
                    <strong>Right to Erasure:</strong> "Delete my data" button that removes all user data within 30 days
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">•</span>
                  <div>
                    <strong>Right to Portability:</strong> Export data to take to competitor services
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">•</span>
                  <div>
                    <strong>Right to Rectification:</strong> Users can correct incorrect information
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">•</span>
                  <div>
                    <strong>Privacy by Design:</strong> Default to most privacy-preserving options
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">•</span>
                  <div>
                    <strong>Data Breach Notification:</strong> Notify users within 72 hours of any breach
                  </div>
                </li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <h4 className="text-slate-900 mb-3">GDPR Documentation</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <div>Detailed Privacy Policy in plain language</div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <div>Data Processing Agreement (DPA) for any third-party processors</div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <div>Data Protection Impact Assessment (DPIA) for voice processing</div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <div>Records of Processing Activities (RoPA)</div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <div>Cookie Policy (if web version exists)</div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <div>Terms of Service with clear data usage explanation</div>
                </li>
              </ul>
            </div>
          </div>

          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <h4 className="text-purple-900 mb-2">Special Considerations for Voice Data</h4>
            <p className="text-sm text-purple-800 mb-3">
              Voice recordings are considered <strong>biometric data</strong> under GDPR Article 9, 
              which requires special category processing. This means:
            </p>
            <ul className="space-y-1 text-sm text-purple-800">
              <li>• Explicit consent required (not just opt-in checkbox)</li>
              <li>• Must demonstrate legitimate interest or legal basis</li>
              <li>• Higher security standards apply</li>
              <li>• Data minimization is mandatory - delete raw audio ASAP</li>
              <li>• Cannot process children's voices without parental consent</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-orange-600" />
            <CardTitle>India IT Rules 2021 Compliance</CardTitle>
          </div>
          <CardDescription>Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
            <h4 className="text-orange-900 mb-3">Key Requirements</h4>
            <ul className="space-y-2 text-sm text-orange-800">
              <li className="flex items-start gap-2">
                <span className="text-orange-600 mt-0.5">•</span>
                <div>
                  <strong>Data Localization:</strong> Sensitive personal data of Indian users must be stored on servers in India
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-600 mt-0.5">•</span>
                <div>
                  <strong>Grievance Officer:</strong> Appoint a resident Grievance Officer in India (name, contact must be published)
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-600 mt-0.5">•</span>
                <div>
                  <strong>User Verification:</strong> For certain categories, one-time verification of users may be required
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-600 mt-0.5">•</span>
                <div>
                  <strong>Content Takedown:</strong> 24-hour response time for law enforcement requests
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-600 mt-0.5">•</span>
                <div>
                  <strong>Significant Social Media Intermediary (SSMI):</strong> If &gt;50 lakh users in India, additional compliance
                </div>
              </li>
            </ul>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="text-blue-900 mb-2">Implementation Strategy for India</h4>
            <ul className="space-y-2 text-sm text-blue-800">
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <span>Host Indian user data in Mumbai/Pune AWS/GCP regions</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <span>Create dedicated India privacy policy page</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <span>Publish Grievance Officer contact on website/app</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <span>Implement geo-fencing to route Indian traffic to India servers</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <span>24/7 monitoring for law enforcement requests</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Eye className="h-5 w-5 text-red-600" />
            <CardTitle>Data Retention & Deletion Policies</CardTitle>
          </div>
          <CardDescription>Minimize data storage to reduce risk</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 border-2 border-green-200 bg-green-50 rounded-lg">
              <h4 className="text-green-900 mb-3">Retention Schedule</h4>
              <div className="space-y-2">
                <div className="p-2 bg-white rounded border">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-slate-900">Original Audio File</span>
                    <Badge className="bg-green-600">7 days</Badge>
                  </div>
                  <p className="text-xs text-slate-600">Deleted after voice signature extracted</p>
                </div>

                <div className="p-2 bg-white rounded border">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-slate-900">Transcription Text</span>
                    <Badge className="bg-amber-600">30 days</Badge>
                  </div>
                  <p className="text-xs text-slate-600">Deleted unless user saves result</p>
                </div>

                <div className="p-2 bg-white rounded border">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-slate-900">Voice Signature (embedding)</span>
                    <Badge className="bg-blue-600">1 year</Badge>
                  </div>
                  <p className="text-xs text-slate-600">Anonymized, for future matching</p>
                </div>

                <div className="p-2 bg-white rounded border">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-slate-900">Analysis Results (saved)</span>
                    <Badge className="bg-purple-600">Until deleted</Badge>
                  </div>
                  <p className="text-xs text-slate-600">User controls retention</p>
                </div>

                <div className="p-2 bg-white rounded border">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-slate-900">Access Logs</span>
                    <Badge className="bg-slate-600">90 days</Badge>
                  </div>
                  <p className="text-xs text-slate-600">Security & compliance only</p>
                </div>
              </div>
            </div>

            <div className="p-4 border-2 border-red-200 bg-red-50 rounded-lg">
              <h4 className="text-red-900 mb-3">Automated Deletion System</h4>
              <ul className="space-y-2 text-sm text-red-800">
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Scheduled cron jobs run daily at 2 AM UTC</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Hard delete from S3 + database (not soft delete)</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Verify deletion with S3 lifecycle policies</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Delete from backups older than retention period</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>User notification 7 days before auto-deletion</span>
                </li>
                <li className="flex gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Deletion confirmation email sent</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg">
            <h4 className="text-slate-900 mb-3">User-Initiated Deletion</h4>
            <p className="text-sm text-slate-600 mb-3">
              Users must be able to delete their data at any time through the app:
            </p>
            <ul className="space-y-1 text-sm text-slate-600">
              <li className="flex gap-2">
                <span className="text-blue-600">→</span>
                <span>Delete individual analysis results</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">→</span>
                <span>Delete all their data ("Right to Erasure")</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">→</span>
                <span>Delete account (cascading delete of all associated data)</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">→</span>
                <span>Deletion confirmation within 72 hours max</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <CardTitle>Legal Considerations & Risk Mitigation</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded">
              <h4 className="text-red-900 mb-2">⚠️ High-Risk Activities to Avoid</h4>
              <ul className="space-y-1 text-sm text-red-800">
                <li>• Recording calls without consent of all parties (illegal in many jurisdictions)</li>
                <li>• Identifying speakers who have not consented to identification</li>
                <li>• Sharing identified information publicly without consent</li>
                <li>• Creating profiles of individuals without their knowledge</li>
                <li>• Using voice data for purposes beyond stated consent</li>
                <li>• Selling or sharing data with third parties for marketing</li>
                <li>• Keeping data longer than stated retention period</li>
              </ul>
            </div>

            <div className="p-4 bg-amber-50 border-l-4 border-amber-500 rounded">
              <h4 className="text-amber-900 mb-2">⚠️ Medium-Risk Activities - Need Safeguards</h4>
              <ul className="space-y-1 text-sm text-amber-800">
                <li>• Crowdsourced spam reporting (verify before publishing)</li>
                <li>• Voice signature matching (anonymize and hash)</li>
                <li>• Location inference (make it opt-in and transparent)</li>
                <li>• Third-party API usage (ensure DPAs in place)</li>
                <li>• Cross-border data transfers (use Standard Contractual Clauses)</li>
              </ul>
            </div>

            <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded">
              <h4 className="text-green-900 mb-2">✓ Low-Risk Best Practices</h4>
              <ul className="space-y-1 text-sm text-green-800">
                <li>• Process voice on-device when possible (iOS/Android ML models)</li>
                <li>• Store only mathematical signatures, not raw audio</li>
                <li>• Anonymize all data before any analysis</li>
                <li>• Give users granular control over their data</li>
                <li>• Be transparent about limitations and uncertainties</li>
                <li>• Regular third-party security audits</li>
                <li>• Have cybersecurity insurance</li>
              </ul>
            </div>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="text-blue-900 mb-3">Recommended Legal Documentation</h4>
            <div className="grid md:grid-cols-2 gap-3">
              <div className="space-y-2 text-sm text-blue-800">
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Privacy Policy (updated quarterly)</span>
                </div>
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Terms of Service</span>
                </div>
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Cookie Policy (if applicable)</span>
                </div>
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Data Processing Agreement (DPA)</span>
                </div>
              </div>
              <div className="space-y-2 text-sm text-blue-800">
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Acceptable Use Policy</span>
                </div>
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Law Enforcement Request Policy</span>
                </div>
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Security Incident Response Plan</span>
                </div>
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>User Consent Forms (multiple languages)</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <h4 className="text-purple-900 mb-2">Consult Legal Experts</h4>
            <p className="text-sm text-purple-800">
              This specification provides technical guidance only. <strong>Consult with privacy lawyers</strong> specializing in:
            </p>
            <ul className="space-y-1 text-sm text-purple-800 mt-2">
              <li>• GDPR compliance (EU lawyer)</li>
              <li>• India data protection laws (Indian lawyer)</li>
              <li>• Biometric data regulations (varies by jurisdiction)</li>
              <li>• Telecommunications laws (if integrating with phone systems)</li>
              <li>• Consumer protection laws in target markets</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}