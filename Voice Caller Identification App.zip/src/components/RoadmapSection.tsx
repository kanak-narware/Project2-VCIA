import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, Circle, Clock, AlertTriangle } from 'lucide-react';

export function RoadmapSection() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>MVP Development Roadmap</CardTitle>
          <CardDescription>Phased approach from prototype to production</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            {/* Phase 1 */}
            <div className="relative">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-green-600 flex items-center justify-center">
                    <span className="text-white">1</span>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="text-slate-900">Phase 1: Foundation (Weeks 1-4)</h3>
                    <Badge className="bg-green-600">Priority</Badge>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <h4 className="text-green-900 mb-3">Backend</h4>
                      <ul className="space-y-2 text-sm text-green-800">
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Setup Node.js/FastAPI server with basic REST API</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Configure PostgreSQL database with schema</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Setup S3 bucket with encryption</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Implement authentication (JWT)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>File upload with presigned URLs</span>
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <h4 className="text-green-900 mb-3">Mobile App</h4>
                      <ul className="space-y-2 text-sm text-green-800">
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>React Native / Flutter project setup</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Basic UI: Home, Upload, Results screens</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Audio recording functionality</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>File picker for existing recordings</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Basic authentication flow</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-slate-50 border rounded">
                    <p className="text-sm text-slate-700"><strong>Deliverable:</strong> Working prototype with file upload and basic API structure</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Phase 2 */}
            <div className="relative">
              <div className="absolute left-6 -top-8 bottom-0 w-0.5 bg-slate-200"></div>
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-blue-600 flex items-center justify-center">
                    <span className="text-white">2</span>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="text-slate-900">Phase 2: Core Processing (Weeks 5-8)</h3>
                    <Badge className="bg-blue-600">Critical</Badge>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <h4 className="text-blue-900 mb-3">ML Pipeline</h4>
                      <ul className="space-y-2 text-sm text-blue-800">
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Integrate Whisper for speech-to-text</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Setup Resemblyzer for voice signatures</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Implement language detection</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Audio preprocessing pipeline</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Quality assessment module</span>
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <h4 className="text-blue-900 mb-3">Processing Infrastructure</h4>
                      <ul className="space-y-2 text-sm text-blue-800">
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Message queue setup (SQS/RabbitMQ)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Worker processes for async analysis</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Progress tracking and status updates</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Error handling and retry logic</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-slate-50 border rounded">
                    <p className="text-sm text-slate-700"><strong>Deliverable:</strong> End-to-end audio processing with transcription and voice analysis</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Phase 3 */}
            <div className="relative">
              <div className="absolute left-6 -top-8 bottom-0 w-0.5 bg-slate-200"></div>
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-purple-600 flex items-center justify-center">
                    <span className="text-white">3</span>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="text-slate-900">Phase 3: Identification Features (Weeks 9-12)</h3>
                    <Badge className="bg-purple-600">Core Value</Badge>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <h4 className="text-purple-900 mb-3">Data Sources</h4>
                      <ul className="space-y-2 text-sm text-purple-800">
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Integrate Twilio Lookup API</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Build voice signature database (pgvector)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Implement similarity search</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Basic spam database integration</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Entity extraction from transcripts</span>
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <h4 className="text-purple-900 mb-3">Analysis Features</h4>
                      <ul className="space-y-2 text-sm text-purple-800">
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Gender estimation (openSMILE)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Location inference (number prefix)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Confidence score calculation</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Result aggregation logic</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-slate-50 border rounded">
                    <p className="text-sm text-slate-700"><strong>Deliverable:</strong> Full caller identification with name, location, and metadata</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Phase 4 */}
            <div className="relative">
              <div className="absolute left-6 -top-8 bottom-0 w-0.5 bg-slate-200"></div>
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-amber-600 flex items-center justify-center">
                    <span className="text-white">4</span>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="text-slate-900">Phase 4: Privacy & Compliance (Weeks 13-16)</h3>
                    <Badge className="bg-red-600">Mandatory</Badge>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                      <h4 className="text-amber-900 mb-3">Security Implementation</h4>
                      <ul className="space-y-2 text-sm text-amber-800">
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>End-to-end encryption</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Consent management system</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Automated data deletion cron jobs</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Audit logging</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Rate limiting and abuse prevention</span>
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                      <h4 className="text-amber-900 mb-3">Legal & Documentation</h4>
                      <ul className="space-y-2 text-sm text-amber-800">
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Privacy Policy (GDPR compliant)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Terms of Service</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Data export functionality</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Account deletion feature</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>India compliance (IT Rules 2021)</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded">
                    <p className="text-sm text-red-800"><strong>Critical:</strong> Cannot launch without full privacy compliance</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Phase 5 */}
            <div className="relative">
              <div className="absolute left-6 -top-8 bottom-0 w-0.5 bg-slate-200"></div>
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-indigo-600 flex items-center justify-center">
                    <span className="text-white">5</span>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="text-slate-900">Phase 5: Polish & Launch (Weeks 17-20)</h3>
                    <Badge variant="outline">Final Sprint</Badge>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                      <h4 className="text-indigo-900 mb-3">User Experience</h4>
                      <ul className="space-y-2 text-sm text-indigo-800">
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Polished UI/UX design</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Feedback system implementation</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Push notifications</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Onboarding flow</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Help documentation</span>
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                      <h4 className="text-indigo-900 mb-3">Testing & Deployment</h4>
                      <ul className="space-y-2 text-sm text-indigo-800">
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Beta testing with 50-100 users</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Performance optimization</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Security audit</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>App store submission</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Circle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                          <span>Production deployment</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded">
                    <p className="text-sm text-green-800"><strong>Deliverable:</strong> Public launch on iOS and Android</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <CardTitle>MVP Feature Scope</CardTitle>
          </div>
          <CardDescription>What to include and exclude in initial release</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <h4 className="text-green-900">Include in MVP</h4>
              </div>
              
              <div className="space-y-2">
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Audio upload (file picker only)</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Speech-to-text (Whisper)</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Voice signature matching</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Language detection</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Phone number lookup (basic)</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Gender estimation</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Country-level location (number prefix)</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Basic spam detection</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Confidence scores</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Rate limiting (10/day free)</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ Auto data deletion (7 days)</p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="text-sm text-green-900">✓ GDPR compliance features</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-3">
                <Clock className="h-5 w-5 text-amber-600" />
                <h4 className="text-amber-900">Defer to Post-MVP</h4>
              </div>
              
              <div className="space-y-2">
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ In-app recording (use file upload first)</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Age estimation (accuracy too low)</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Emotion detection (nice-to-have)</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ City-level location (wait for more data)</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Real-time call identification (complex integration)</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Social media profile matching</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Advanced spam categorization</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Community reporting features</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Premium tiers (start with free only)</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Web dashboard (mobile-first)</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Batch processing</p>
                </div>
                <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                  <p className="text-sm text-amber-900">○ Advanced analytics dashboard</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-red-600" />
            <CardTitle>Ethical Guardrails</CardTitle>
          </div>
          <CardDescription>Preventing misuse and protecting users</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-red-50 border-2 border-red-300 rounded-lg">
              <h4 className="text-red-900 mb-3">Mandatory Limitations</h4>
              <ul className="space-y-2 text-sm text-red-800">
                <li className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>No Recording Without Consent:</strong> App must not facilitate recording calls without all parties' knowledge (illegal in many jurisdictions)
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>No Stalking Features:</strong> Do not enable location tracking or continuous monitoring of individuals
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>No Public Exposure:</strong> Never publicly display identified information without explicit consent
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>No Children's Data:</strong> Reject processing of voices identified as children (under 13) without verified parental consent
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>No Sell/Share:</strong> Never sell user data or voice signatures to third parties
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Clear Uncertainty:</strong> Always display confidence scores - never present uncertain data as fact
                  </div>
                </li>
              </ul>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="text-blue-900 mb-3">Abuse Prevention Mechanisms</h4>
              <ul className="space-y-2 text-sm text-blue-800">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Strict rate limiting (prevent mass surveillance)</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Flag suspicious patterns (same user analyzing many different voices)</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Require identity verification for high-volume users</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Manual review of flagged accounts</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Report abuse button (users can report misuse)</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Acceptable Use Policy with enforcement</span>
                </li>
              </ul>
            </div>

            <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <h4 className="text-purple-900 mb-3">Transparency Measures</h4>
              <ul className="space-y-2 text-sm text-purple-800">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Public transparency report (quarterly): requests received, accounts banned, etc.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Clear explanation of how each data point was determined</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Accuracy statistics published (% of correct identifications based on user feedback)</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>Open about limitations (what the system cannot do)</span>
                </li>
              </ul>
            </div>

            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <h4 className="text-amber-900 mb-2">Recommended: Ethics Advisory Board</h4>
              <p className="text-sm text-amber-800">
                Consider establishing an independent ethics board with privacy advocates, legal experts, and 
                technologists to review features and policies quarterly. This demonstrates commitment to 
                responsible development and can help identify issues before they become problems.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Post-MVP Roadmap (6-12 months)</CardTitle>
          <CardDescription>Future enhancements after successful launch</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg">
              <Badge className="mb-3">Q1 Post-Launch</Badge>
              <h4 className="text-slate-900 mb-2">Enhancement Phase</h4>
              <ul className="space-y-1 text-sm text-slate-600">
                <li>• In-app recording</li>
                <li>• Improved UI/UX based on feedback</li>
                <li>• Community spam reporting</li>
                <li>• Premium tier launch</li>
                <li>• Web dashboard</li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <Badge className="mb-3">Q2-Q3</Badge>
              <h4 className="text-slate-900 mb-2">Advanced Features</h4>
              <ul className="space-y-1 text-sm text-slate-600">
                <li>• Real-time call screening</li>
                <li>• Social media integration</li>
                <li>• Advanced spam categorization</li>
                <li>• Batch processing</li>
                <li>• API for third-party apps</li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <Badge className="mb-3">Q4+</Badge>
              <h4 className="text-slate-900 mb-2">Scale & Expand</h4>
              <ul className="space-y-1 text-sm text-slate-600">
                <li>• Additional language support</li>
                <li>• Enterprise features</li>
                <li>• Custom ML model training</li>
                <li>• International expansion</li>
                <li>• Partnership integrations</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
