import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';

export function DataFormatsSection() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Input Formats</CardTitle>
          <CardDescription>Accepted audio formats and requirements</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="p-4 border rounded-lg">
                <h4 className="text-slate-900 mb-2">Audio Formats</h4>
                <ul className="space-y-1 text-sm text-slate-600">
                  <li>• MP3 (preferred)</li>
                  <li>• WAV (lossless)</li>
                  <li>• M4A / AAC</li>
                  <li>• OGG</li>
                  <li>• FLAC</li>
                </ul>
              </div>

              <div className="p-4 border rounded-lg">
                <h4 className="text-slate-900 mb-2">Size Limits</h4>
                <ul className="space-y-1 text-sm text-slate-600">
                  <li>• Max file size: 50 MB</li>
                  <li>• Max duration: 5 minutes</li>
                  <li>• Min duration: 3 seconds</li>
                  <li>• Recommended: 10-60 seconds</li>
                </ul>
              </div>

              <div className="p-4 border rounded-lg">
                <h4 className="text-slate-900 mb-2">Quality Requirements</h4>
                <ul className="space-y-1 text-sm text-slate-600">
                  <li>• Min sample rate: 8 kHz</li>
                  <li>• Recommended: 16+ kHz</li>
                  <li>• Mono or stereo</li>
                  <li>• Min SNR: 10 dB</li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="text-slate-900 mb-3">Example Upload Request</h4>
              <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`POST /api/v1/analyze
Content-Type: multipart/form-data

{
  "audio_file": <binary_data>,
  "metadata": {
    "timestamp": "2025-10-24T10:30:00Z",
    "caller_number": "+91-9876543210", // optional
    "user_id": "usr_abc123",
    "consent": true,
    "retention_days": 7 // optional, default 30
  }
}`}
              </pre>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Output Formats</CardTitle>
          <CardDescription>API response structure and example responses</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="success">
            <TabsList>
              <TabsTrigger value="success">Success Response</TabsTrigger>
              <TabsTrigger value="partial">Partial Match</TabsTrigger>
              <TabsTrigger value="error">Error Cases</TabsTrigger>
            </TabsList>

            <TabsContent value="success" className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Badge className="bg-green-600">200 OK</Badge>
                  <span className="text-sm text-green-800">High confidence match found</span>
                </div>
                <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`{
  "status": "success",
  "analysis_id": "ana_xyz789",
  "timestamp": "2025-10-24T10:30:15Z",
  "processing_time_ms": 2340,
  
  "caller_info": {
    "name": {
      "value": "John Doe",
      "confidence": 0.95,
      "source": "public_directory",
      "verified": false
    },
    "location": {
      "country": "India",
      "state": "Maharashtra",
      "city": "Mumbai",
      "coordinates": {
        "lat": 19.0760,
        "lng": 72.8777
      },
      "confidence": 0.67,
      "source": "number_prefix_inference",
      "accuracy_radius_km": 50
    },
    "phone_number": {
      "value": "+91-9876543210",
      "confidence": 0.82,
      "source": "voice_signature_match"
    }
  },
  
  "voice_analysis": {
    "language": {
      "primary": "en-IN",
      "name": "English (Indian)",
      "confidence": 0.92,
      "accent": "Mumbai region"
    },
    "gender": {
      "value": "male",
      "confidence": 0.88
    },
    "age_estimate": {
      "range": "30-40",
      "confidence": 0.64
    },
    "emotion": {
      "primary": "neutral",
      "secondary": "professional",
      "confidence": 0.71
    },
    "speaker_id": "spk_abc123xyz",
    "voice_signature_hash": "sha256:a1b2c3..."
  },
  
  "audio_quality": {
    "sample_rate": 16000,
    "duration_seconds": 23.4,
    "snr_db": 18.5,
    "quality_score": 0.85,
    "background_noise": "low"
  },
  
  "transcription": {
    "text": "Hello, this is John calling from ABC Company...",
    "confidence": 0.89,
    "language": "en-IN",
    "entities_detected": [
      {
        "type": "organization",
        "value": "ABC Company",
        "confidence": 0.91
      }
    ]
  },
  
  "spam_analysis": {
    "is_spam": false,
    "spam_score": 0.12,
    "report_count": 0,
    "categories": []
  },
  
  "similar_matches": [
    {
      "caller_id": "caller_xyz456",
      "similarity_score": 0.78,
      "name": "J. Doe",
      "match_reason": "voice_similarity"
    }
  ],
  
  "confidence_overall": 0.84,
  
  "data_retention": {
    "expires_at": "2025-10-31T10:30:15Z",
    "can_extend": true
  }
}`}
                </pre>
              </div>
            </TabsContent>

            <TabsContent value="partial" className="space-y-4">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Badge className="bg-amber-600">200 OK</Badge>
                  <span className="text-sm text-amber-800">Partial information available</span>
                </div>
                <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`{
  "status": "partial",
  "analysis_id": "ana_partial123",
  "timestamp": "2025-10-24T10:35:00Z",
  "processing_time_ms": 2100,
  
  "caller_info": {
    "name": null,
    "location": {
      "country": "India",
      "state": "Unknown",
      "city": "Unknown",
      "confidence": 0.45,
      "source": "number_prefix_inference"
    }
  },
  
  "voice_analysis": {
    "language": {
      "primary": "hi-IN",
      "name": "Hindi",
      "confidence": 0.87
    },
    "gender": {
      "value": "female",
      "confidence": 0.76
    },
    "speaker_id": "spk_new987"
  },
  
  "audio_quality": {
    "quality_score": 0.62,
    "background_noise": "moderate",
    "warnings": ["Low audio quality may affect accuracy"]
  },
  
  "spam_analysis": {
    "is_spam": true,
    "spam_score": 0.78,
    "report_count": 143,
    "categories": ["telemarketing", "sales"]
  },
  
  "confidence_overall": 0.58,
  
  "suggestions": [
    "Audio quality is moderate - a clearer recording may improve results",
    "No name match found in public directories",
    "This number has been reported as spam by other users"
  ]
}`}
                </pre>
              </div>
            </TabsContent>

            <TabsContent value="error" className="space-y-4">
              <div className="space-y-4">
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-red-600">400 Bad Request</Badge>
                    <span className="text-sm text-red-800">Invalid input</span>
                  </div>
                  <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`{
  "status": "error",
  "error_code": "INVALID_AUDIO_FORMAT",
  "message": "Audio format not supported",
  "details": {
    "accepted_formats": ["mp3", "wav", "m4a", "ogg", "flac"],
    "received_format": "avi"
  }
}`}
                  </pre>
                </div>

                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-red-600">422 Unprocessable Entity</Badge>
                    <span className="text-sm text-red-800">Audio quality too low</span>
                  </div>
                  <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`{
  "status": "error",
  "error_code": "AUDIO_QUALITY_TOO_LOW",
  "message": "Audio quality below minimum threshold",
  "details": {
    "snr_db": 4.2,
    "minimum_required": 10.0,
    "quality_score": 0.23
  },
  "suggestions": [
    "Try recording in a quieter environment",
    "Ensure microphone is working properly",
    "Upload a higher quality recording"
  ]
}`}
                  </pre>
                </div>

                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-red-600">429 Too Many Requests</Badge>
                    <span className="text-sm text-red-800">Rate limit exceeded</span>
                  </div>
                  <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`{
  "status": "error",
  "error_code": "RATE_LIMIT_EXCEEDED",
  "message": "Daily analysis limit reached",
  "details": {
    "limit": 10,
    "used": 10,
    "resets_at": "2025-10-25T00:00:00Z",
    "retry_after_seconds": 43200
  }
}`}
                  </pre>
                </div>

                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-red-600">403 Forbidden</Badge>
                    <span className="text-sm text-red-800">Consent required</span>
                  </div>
                  <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`{
  "status": "error",
  "error_code": "CONSENT_REQUIRED",
  "message": "User consent not provided",
  "details": {
    "required_consents": [
      "audio_processing",
      "data_storage",
      "terms_of_service"
    ],
    "provided_consents": []
  }
}`}
                  </pre>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
