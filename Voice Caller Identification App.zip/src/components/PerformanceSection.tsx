import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Zap, TrendingUp, AlertCircle } from 'lucide-react';

export function PerformanceSection() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-600" />
            <CardTitle>Performance Targets</CardTitle>
          </div>
          <CardDescription>Service Level Objectives (SLOs) for production</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="text-slate-900">Response Time Targets</h4>
              <div className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Upload Initiation</span>
                    <Badge className="bg-green-600">Fast</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Target:</span>
                    <span className="text-slate-900">&lt; 500ms</span>
                  </div>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Audio Processing (10s clip)</span>
                    <Badge className="bg-blue-600">Medium</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Target:</span>
                    <span className="text-slate-900">5-15 seconds</span>
                  </div>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Audio Processing (60s clip)</span>
                    <Badge className="bg-amber-600">Slower</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Target:</span>
                    <span className="text-slate-900">30-90 seconds</span>
                  </div>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Database Lookup</span>
                    <Badge className="bg-green-600">Fast</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Target:</span>
                    <span className="text-slate-900">&lt; 200ms</span>
                  </div>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">API Response (results)</span>
                    <Badge className="bg-green-600">Fast</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Target:</span>
                    <span className="text-slate-900">&lt; 1 second</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-slate-900">Availability & Reliability</h4>
              <div className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Uptime SLA</span>
                    <Badge className="bg-green-600">99.5%</Badge>
                  </div>
                  <p className="text-sm text-slate-600">Max 3.65 hours downtime/month</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Error Rate</span>
                    <Badge className="bg-green-600">&lt; 0.1%</Badge>
                  </div>
                  <p className="text-sm text-slate-600">99.9% of requests succeed</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Processing Success Rate</span>
                    <Badge className="bg-amber-600">&gt; 85%</Badge>
                  </div>
                  <p className="text-sm text-slate-600">At least partial results returned</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Data Loss Rate</span>
                    <Badge className="bg-green-600">0%</Badge>
                  </div>
                  <p className="text-sm text-slate-600">Zero uploaded files lost</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            <CardTitle>Rate Limits</CardTitle>
          </div>
          <CardDescription>Anti-abuse and cost control measures</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
                <h4 className="text-blue-900 mb-3">Free Tier</h4>
                <div className="space-y-2 text-sm text-blue-800">
                  <div className="flex justify-between">
                    <span>Daily Analyses:</span>
                    <strong>10</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Analyses:</span>
                    <strong>100</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Max File Size:</span>
                    <strong>25 MB</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Max Duration:</span>
                    <strong>3 min</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Concurrent Requests:</span>
                    <strong>1</strong>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-green-50 border-2 border-green-200 rounded-lg">
                <h4 className="text-green-900 mb-3">Premium Tier</h4>
                <div className="space-y-2 text-sm text-green-800">
                  <div className="flex justify-between">
                    <span>Daily Analyses:</span>
                    <strong>100</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Analyses:</span>
                    <strong>Unlimited</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Max File Size:</span>
                    <strong>50 MB</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Max Duration:</span>
                    <strong>5 min</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Concurrent Requests:</span>
                    <strong>3</strong>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-purple-50 border-2 border-purple-200 rounded-lg">
                <h4 className="text-purple-900 mb-3">Enterprise Tier</h4>
                <div className="space-y-2 text-sm text-purple-800">
                  <div className="flex justify-between">
                    <span>Daily Analyses:</span>
                    <strong>Custom</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Analyses:</span>
                    <strong>Unlimited</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Max File Size:</span>
                    <strong>100 MB</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Max Duration:</span>
                    <strong>10 min</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Concurrent Requests:</span>
                    <strong>10</strong>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <h4 className="text-amber-900 mb-3">Rate Limit Implementation</h4>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-amber-800 mb-2">Algorithm: Token Bucket</p>
                  <ul className="space-y-1 text-sm text-amber-800">
                    <li>• Tokens refill at steady rate</li>
                    <li>• Burst capacity for occasional spikes</li>
                    <li>• Per-user tracking via Redis</li>
                    <li>• 429 status code when exceeded</li>
                  </ul>
                </div>
                <div>
                  <p className="text-sm text-amber-800 mb-2">Response Headers:</p>
                  <pre className="text-xs bg-slate-900 text-slate-100 p-2 rounded">
{`X-RateLimit-Limit: 10
X-RateLimit-Remaining: 7
X-RateLimit-Reset: 1729785600
Retry-After: 43200`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-purple-600" />
            <CardTitle>Confidence Score Thresholds</CardTitle>
          </div>
          <CardDescription>When to return results vs. "no match found"</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <h4 className="text-purple-900 mb-3">Confidence Scoring System</h4>
              <p className="text-sm text-purple-800 mb-4">
                Each data point (name, location, language, etc.) has an individual confidence score (0.0 to 1.0). 
                The overall confidence is a weighted average based on reliability of each source.
              </p>
              <div className="grid md:grid-cols-3 gap-3">
                <div className="p-3 bg-white rounded border-2 border-green-500">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-green-900">High Confidence</span>
                    <Badge className="bg-green-600">≥ 0.75</Badge>
                  </div>
                  <p className="text-sm text-green-800">Display prominently, user can trust</p>
                </div>

                <div className="p-3 bg-white rounded border-2 border-amber-500">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-amber-900">Medium Confidence</span>
                    <Badge className="bg-amber-600">0.50 - 0.74</Badge>
                  </div>
                  <p className="text-sm text-amber-800">Display with warning, possible match</p>
                </div>

                <div className="p-3 bg-white rounded border-2 border-red-500">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-red-900">Low Confidence</span>
                    <Badge className="bg-red-600">&lt; 0.50</Badge>
                  </div>
                  <p className="text-sm text-red-800">Don't display or show as "uncertain"</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-slate-900">Field-Specific Thresholds</h4>
              
              <div className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Caller Name</span>
                  <Badge>Min: 0.70</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  High threshold - false positive could be problematic (wrong accusation)
                </p>
              </div>

              <div className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Location (Country)</span>
                  <Badge>Min: 0.60</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  Medium threshold - location is inherently uncertain
                </p>
              </div>

              <div className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Location (City)</span>
                  <Badge>Min: 0.50</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  Lower threshold - city-level is approximate anyway
                </p>
              </div>

              <div className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Language</span>
                  <Badge>Min: 0.80</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  High threshold - language detection is usually very accurate
                </p>
              </div>

              <div className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Gender</span>
                  <Badge>Min: 0.65</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  Medium threshold - voice-based gender estimation has limitations
                </p>
              </div>

              <div className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-900">Spam Classification</span>
                  <Badge>Min: 0.75</Badge>
                </div>
                <p className="text-sm text-slate-600">
                  High threshold - don't want to mislabel legitimate callers as spam
                </p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="text-slate-900 mb-3">Confidence Calculation Example</h4>
              <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`function calculateOverallConfidence(results) {
  const weights = {
    name: 0.30,           // Name is most important
    voice_match: 0.25,    // Voice signature match
    phone_lookup: 0.20,   // Phone number data
    language: 0.10,       // Language detection
    location: 0.10,       // Location inference
    spam_score: 0.05      // Spam database
  };
  
  let totalWeight = 0;
  let weightedSum = 0;
  
  for (const [field, weight] of Object.entries(weights)) {
    if (results[field] && results[field].confidence) {
      weightedSum += results[field].confidence * weight;
      totalWeight += weight;
    }
  }
  
  const overallConfidence = totalWeight > 0 
    ? weightedSum / totalWeight 
    : 0;
  
  return {
    overall: overallConfidence,
    display: overallConfidence >= 0.50, // Only show if ≥ 50%
    quality: overallConfidence >= 0.75 ? 'high' :
             overallConfidence >= 0.50 ? 'medium' : 'low'
  };
}`}
              </pre>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Scalability Considerations</CardTitle>
          <CardDescription>Handling growth from 100 to 1M+ users</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="text-blue-900 mb-3">Horizontal Scaling Strategies</h4>
                <ul className="space-y-2 text-sm text-blue-800">
                  <li className="flex gap-2">
                    <span className="text-blue-600">•</span>
                    <span>Stateless API servers (scale with load balancer)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-blue-600">•</span>
                    <span>Message queue for async processing (SQS/RabbitMQ)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-blue-600">•</span>
                    <span>Worker pool auto-scaling based on queue depth</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-blue-600">•</span>
                    <span>Database read replicas for query scaling</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-blue-600">•</span>
                    <span>CDN for static assets and presigned URLs</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-blue-600">•</span>
                    <span>Redis cluster for distributed caching</span>
                  </li>
                </ul>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="text-green-900 mb-3">Database Optimization</h4>
                <ul className="space-y-2 text-sm text-green-800">
                  <li className="flex gap-2">
                    <span className="text-green-600">•</span>
                    <span>Index on user_id, timestamp, analysis_id</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-green-600">•</span>
                    <span>Partition by date (monthly partitions)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-green-600">•</span>
                    <span>pgvector index for voice signature similarity</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-green-600">•</span>
                    <span>Archive old data to cold storage (S3 Glacier)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-green-600">•</span>
                    <span>Connection pooling (PgBouncer)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-green-600">•</span>
                    <span>Query caching for common lookups</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <h4 className="text-purple-900 mb-3">Capacity Planning</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-purple-300">
                      <th className="text-left py-2 text-purple-900">Users</th>
                      <th className="text-left py-2 text-purple-900">Daily Analyses</th>
                      <th className="text-left py-2 text-purple-900">API Servers</th>
                      <th className="text-left py-2 text-purple-900">Workers</th>
                      <th className="text-left py-2 text-purple-900">DB Size</th>
                      <th className="text-left py-2 text-purple-900">Storage</th>
                    </tr>
                  </thead>
                  <tbody className="text-purple-800">
                    <tr className="border-b border-purple-200">
                      <td className="py-2">1,000</td>
                      <td className="py-2">500</td>
                      <td className="py-2">2</td>
                      <td className="py-2">3</td>
                      <td className="py-2">10 GB</td>
                      <td className="py-2">50 GB</td>
                    </tr>
                    <tr className="border-b border-purple-200">
                      <td className="py-2">10,000</td>
                      <td className="py-2">5,000</td>
                      <td className="py-2">4</td>
                      <td className="py-2">10</td>
                      <td className="py-2">100 GB</td>
                      <td className="py-2">500 GB</td>
                    </tr>
                    <tr className="border-b border-purple-200">
                      <td className="py-2">100,000</td>
                      <td className="py-2">50,000</td>
                      <td className="py-2">10</td>
                      <td className="py-2">30</td>
                      <td className="py-2">1 TB</td>
                      <td className="py-2">5 TB</td>
                    </tr>
                    <tr>
                      <td className="py-2">1,000,000</td>
                      <td className="py-2">500,000</td>
                      <td className="py-2">50</td>
                      <td className="py-2">100</td>
                      <td className="py-2">10 TB</td>
                      <td className="py-2">50 TB</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}