import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Upload, Mic, Loader2, CheckCircle, AlertCircle, MessageSquare, ChevronRight } from 'lucide-react';

export function UserFlowSection() {
  const flowSteps = [
    {
      icon: Upload,
      title: "1. Upload/Record",
      color: "blue",
      screens: [
        "Home Screen: Upload button and Record button",
        "File picker for existing recordings (mp3, wav, m4a)",
        "In-app recorder with waveform visualization",
        "Duration limit: 5 minutes max per clip"
      ],
      wireframe: {
        elements: ["Large centered upload area", "Or Record new audio button", "Recent submissions list", "Privacy consent checkbox"]
      }
    },
    {
      icon: Loader2,
      title: "2. Processing",
      color: "amber",
      screens: [
        "Upload progress bar (chunked upload for large files)",
        "Processing status with estimated time",
        "Stage indicators: Upload → Analysis → Matching → Results",
        "Cancellation option during processing"
      ],
      wireframe: {
        elements: ["Circular progress indicator", "Processing stage labels", "Cancel button", "Tips about privacy while waiting"]
      }
    },
    {
      icon: CheckCircle,
      title: "3. Results",
      color: "green",
      screens: [
        "Caller information card with confidence scores",
        "Expandable sections for each data type",
        "Visual indicators (High/Medium/Low confidence)",
        "Action buttons: Save, Share, Report Wrong"
      ],
      wireframe: {
        elements: ["Profile summary card", "Metadata sections", "Confidence badges", "Action toolbar", "Similar matches section"]
      }
    },
    {
      icon: MessageSquare,
      title: "4. Feedback",
      color: "purple",
      screens: [
        "Rate accuracy (1-5 stars)",
        "Report incorrect information",
        "Add additional context",
        "Flag as spam/scam"
      ],
      wireframe: {
        elements: ["Feedback form", "Star rating", "Text input", "Category selection", "Submit button"]
      }
    }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>User Flow Overview</CardTitle>
          <CardDescription>Complete journey from audio submission to results and feedback</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            {flowSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="relative">
                  {index < flowSteps.length - 1 && (
                    <div className="absolute left-6 top-12 bottom-0 w-0.5 bg-slate-200" />
                  )}
                  
                  <div className="flex gap-4">
                    <div className={`h-12 w-12 rounded-full bg-${step.color}-100 flex items-center justify-center flex-shrink-0 relative z-10`}>
                      <Icon className={`h-6 w-6 text-${step.color}-600`} />
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="text-slate-900 mb-3">{step.title}</h3>
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm text-slate-700 mb-2">User Actions & Screens</h4>
                          <ul className="space-y-2">
                            {step.screens.map((screen, i) => (
                              <li key={i} className="text-sm text-slate-600 flex gap-2">
                                <ChevronRight className="h-4 w-4 text-slate-400 flex-shrink-0 mt-0.5" />
                                {screen}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="text-sm text-slate-700 mb-2">Wireframe Elements</h4>
                          <div className="p-4 bg-slate-50 rounded-lg border-2 border-dashed border-slate-300">
                            {step.wireframe.elements.map((element, i) => (
                              <div key={i} className="py-2 border-b border-slate-200 last:border-0">
                                <span className="text-sm text-slate-600">{element}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detailed Screen Specifications</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-slate-900">Home Screen (Upload/Record)</h3>
            <div className="p-6 bg-white border-2 border-slate-200 rounded-lg">
              <div className="space-y-4">
                <div className="text-center p-8 border-2 border-dashed border-blue-300 bg-blue-50 rounded-lg">
                  <Upload className="h-12 w-12 text-blue-600 mx-auto mb-3" />
                  <p className="text-slate-900 mb-2">Upload Voice Recording</p>
                  <p className="text-sm text-slate-600">MP3, WAV, M4A up to 50MB</p>
                </div>
                
                <div className="text-center py-2">
                  <span className="text-slate-500">or</span>
                </div>
                
                <button className="w-full p-4 bg-red-500 text-white rounded-lg flex items-center justify-center gap-2">
                  <Mic className="h-5 w-5" />
                  Record New Audio
                </button>
                
                <div className="pt-4 border-t">
                  <div className="flex items-start gap-2">
                    <input type="checkbox" className="mt-1" />
                    <p className="text-sm text-slate-600">
                      I consent to processing this audio for caller identification (Required)
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-slate-900">Results Screen</h3>
            <div className="p-6 bg-white border-2 border-slate-200 rounded-lg space-y-4">
              <div className="flex items-start gap-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h4 className="text-green-900 mb-1">Analysis Complete</h4>
                  <p className="text-sm text-green-800">Match found with high confidence</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-700">Likely Name</span>
                    <Badge className="bg-green-100 text-green-800">95% confidence</Badge>
                  </div>
                  <p className="text-slate-900">John Doe</p>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-700">Location</span>
                    <Badge className="bg-amber-100 text-amber-800">67% confidence</Badge>
                  </div>
                  <p className="text-slate-900">Mumbai, Maharashtra, India</p>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-700">Language</span>
                    <Badge className="bg-green-100 text-green-800">92% confidence</Badge>
                  </div>
                  <p className="text-slate-900">English (Indian accent)</p>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-700">Gender Estimate</span>
                    <Badge className="bg-green-100 text-green-800">88% confidence</Badge>
                  </div>
                  <p className="text-slate-900">Male</p>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg">Save</button>
                <button className="flex-1 px-4 py-2 border border-slate-300 rounded-lg">Share</button>
                <button className="px-4 py-2 border border-red-300 text-red-600 rounded-lg">Report Wrong</button>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-slate-900">Error States</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex gap-3">
                  <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-red-900 mb-1">No Match Found</h4>
                    <p className="text-sm text-red-800">Unable to identify caller from available data sources</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-amber-900 mb-1">Low Quality Audio</h4>
                    <p className="text-sm text-amber-800">Audio quality too low for reliable analysis</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-amber-900 mb-1">Processing Timeout</h4>
                    <p className="text-sm text-amber-800">Analysis taking longer than expected, please try again</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex gap-3">
                  <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-red-900 mb-1">Rate Limit Exceeded</h4>
                    <p className="text-sm text-red-800">You've reached your daily limit. Try again in 24 hours</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
