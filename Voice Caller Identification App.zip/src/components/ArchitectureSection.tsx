import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Smartphone, Server, Database, Cloud, Lock, Zap } from 'lucide-react';

export function ArchitectureSection() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>System Architecture Overview</CardTitle>
          <CardDescription>High-level architecture and data flow</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg border-2 border-blue-200">
              <div className="space-y-8">
                {/* Mobile App Layer */}
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-lg bg-blue-600 flex items-center justify-center flex-shrink-0">
                    <Smartphone className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-slate-900 mb-2">Mobile App Layer</h4>
                    <div className="grid md:grid-cols-3 gap-3">
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">React Native / Flutter</p>
                        <p className="text-xs text-slate-600">Cross-platform UI</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Audio Recording</p>
                        <p className="text-xs text-slate-600">Native APIs</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Local Encryption</p>
                        <p className="text-xs text-slate-600">Before upload</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center">
                  <div className="h-8 w-0.5 bg-slate-400"></div>
                </div>

                {/* API Gateway Layer */}
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-lg bg-green-600 flex items-center justify-center flex-shrink-0">
                    <Server className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-slate-900 mb-2">API Gateway & Load Balancer</h4>
                    <div className="grid md:grid-cols-3 gap-3">
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">NGINX / Kong</p>
                        <p className="text-xs text-slate-600">Rate limiting, auth</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Request Validation</p>
                        <p className="text-xs text-slate-600">Size, format checks</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">SSL/TLS Termination</p>
                        <p className="text-xs text-slate-600">HTTPS only</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center">
                  <div className="h-8 w-0.5 bg-slate-400"></div>
                </div>

                {/* Processing Layer */}
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-lg bg-purple-600 flex items-center justify-center flex-shrink-0">
                    <Zap className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-slate-900 mb-2">Processing & Analysis Layer</h4>
                    <div className="grid md:grid-cols-4 gap-3">
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Audio Processing</p>
                        <p className="text-xs text-slate-600">Normalization, cleanup</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Speech-to-Text</p>
                        <p className="text-xs text-slate-600">Transcription service</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Voice Analysis</p>
                        <p className="text-xs text-slate-600">Biometrics, features</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Matching Engine</p>
                        <p className="text-xs text-slate-600">Database lookup</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center">
                  <div className="h-8 w-0.5 bg-slate-400"></div>
                </div>

                {/* Data Layer */}
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-lg bg-amber-600 flex items-center justify-center flex-shrink-0">
                    <Database className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-slate-900 mb-2">Data Storage Layer</h4>
                    <div className="grid md:grid-cols-3 gap-3">
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">PostgreSQL</p>
                        <p className="text-xs text-slate-600">Metadata, users, results</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">S3 / Cloud Storage</p>
                        <p className="text-xs text-slate-600">Encrypted audio files</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Redis</p>
                        <p className="text-xs text-slate-600">Caching, sessions</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center">
                  <div className="h-8 w-0.5 bg-slate-400"></div>
                </div>

                {/* External Services */}
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-lg bg-indigo-600 flex items-center justify-center flex-shrink-0">
                    <Cloud className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-slate-900 mb-2">External Services & APIs</h4>
                    <div className="grid md:grid-cols-4 gap-3">
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Google Speech API</p>
                        <p className="text-xs text-slate-600">STT, language detection</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Twilio Lookup</p>
                        <p className="text-xs text-slate-600">Phone number data</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">MaxMind GeoIP</p>
                        <p className="text-xs text-slate-600">Location inference</p>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <p className="text-sm text-slate-900 mb-1">Spam Databases</p>
                        <p className="text-xs text-slate-600">Truecaller, etc.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Data Flow Diagram</CardTitle>
          <CardDescription>Step-by-step processing pipeline</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                step: 1,
                title: "Audio Upload",
                description: "Client uploads encrypted audio via chunked multipart upload",
                details: ["Client-side encryption (AES-256)", "Chunked upload for large files", "Progress tracking", "Upload to S3 with presigned URL"]
              },
              {
                step: 2,
                title: "Validation & Queuing",
                description: "API validates request and queues for processing",
                details: ["Format validation", "Size and duration checks", "Consent verification", "Add to processing queue (SQS/RabbitMQ)"]
              },
              {
                step: 3,
                title: "Audio Preprocessing",
                description: "Worker processes audio for analysis",
                details: ["Decrypt audio", "Format conversion (to WAV/PCM)", "Noise reduction", "Normalization", "Quality assessment"]
              },
              {
                step: 4,
                title: "Parallel Analysis",
                description: "Multiple analysis pipelines run simultaneously",
                details: [
                  "Speech-to-Text transcription",
                  "Language detection",
                  "Speaker diarization",
                  "Voice feature extraction (MFCC, pitch, etc.)",
                  "Gender/age estimation"
                ]
              },
              {
                step: 5,
                title: "Database Matching",
                description: "Match voice signatures and metadata against databases",
                details: [
                  "Voice signature comparison (cosine similarity)",
                  "Phone number lookup (if available)",
                  "Name entity extraction from transcription",
                  "Spam database check",
                  "Similar caller search"
                ]
              },
              {
                step: 6,
                title: "Result Aggregation",
                description: "Combine results and calculate confidence scores",
                details: [
                  "Merge data from multiple sources",
                  "Calculate confidence scores",
                  "Resolve conflicts",
                  "Generate overall confidence"
                ]
              },
              {
                step: 7,
                title: "Response & Storage",
                description: "Return results to client and store for future reference",
                details: [
                  "Format response JSON",
                  "Store analysis results",
                  "Update voice signature database",
                  "Send push notification if async",
                  "Schedule auto-deletion"
                ]
              }
            ].map((item) => (
              <div key={item.step} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-blue-600 text-white flex items-center justify-center">
                    {item.step}
                  </div>
                </div>
                <div className="flex-1">
                  <h4 className="text-slate-900 mb-1">{item.title}</h4>
                  <p className="text-sm text-slate-600 mb-2">{item.description}</p>
                  <ul className="space-y-1">
                    {item.details.map((detail, idx) => (
                      <li key={idx} className="text-sm text-slate-500 flex gap-2">
                        <span className="text-blue-500">→</span>
                        {detail}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Technology Stack Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="text-slate-900">Backend Services</h4>
              <div className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">API Server</span>
                    <Badge>Recommended</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">Node.js (Express/Fastify) or Python (FastAPI)</p>
                  <p className="text-xs text-slate-500">Async processing, good library support</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Audio Processing</span>
                    <Badge>Recommended</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">Python (librosa, pydub, scipy)</p>
                  <p className="text-xs text-slate-500">Rich ML/audio ecosystem</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Message Queue</span>
                    <Badge>Recommended</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">AWS SQS or RabbitMQ</p>
                  <p className="text-xs text-slate-500">Async job processing</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Container Orchestration</span>
                    <Badge>Recommended</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">Kubernetes or AWS ECS</p>
                  <p className="text-xs text-slate-500">Scalable microservices</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-slate-900">Storage & Data</h4>
              <div className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Primary Database</span>
                    <Badge>Recommended</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">PostgreSQL 15+</p>
                  <p className="text-xs text-slate-500">JSONB support, pgvector for embeddings</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Object Storage</span>
                    <Badge>Recommended</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">AWS S3 or Google Cloud Storage</p>
                  <p className="text-xs text-slate-500">Encrypted audio files, lifecycle policies</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Caching Layer</span>
                    <Badge>Recommended</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">Redis 7+</p>
                  <p className="text-xs text-slate-500">Session management, rate limiting</p>
                </div>

                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-900">Vector Database</span>
                    <Badge variant="outline">Optional</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">Pinecone or Weaviate</p>
                  <p className="text-xs text-slate-500">Voice signature similarity search</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Handling Large Audio Files</CardTitle>
          <CardDescription>Strategies for efficient upload and processing</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="text-blue-900 mb-2">Chunked Upload</h4>
                <ul className="space-y-2 text-sm text-blue-800">
                  <li>• Split files into 5MB chunks</li>
                  <li>• Upload in parallel (up to 3 simultaneous)</li>
                  <li>• Resume capability for failed uploads</li>
                  <li>• Client-side MD5 checksum verification</li>
                </ul>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="text-green-900 mb-2">Presigned URLs</h4>
                <ul className="space-y-2 text-sm text-green-800">
                  <li>• Direct S3 upload (bypass API server)</li>
                  <li>• Time-limited access (15 min expiry)</li>
                  <li>• Reduces backend load</li>
                  <li>• Faster upload speeds</li>
                </ul>
              </div>

              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <h4 className="text-purple-900 mb-2">Compression</h4>
                <ul className="space-y-2 text-sm text-purple-800">
                  <li>• Client-side compression (gzip)</li>
                  <li>• Recommend MP3 over WAV</li>
                  <li>• Configurable bitrate (64-128 kbps sufficient)</li>
                  <li>• Auto-convert high-res audio</li>
                </ul>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <h4 className="text-amber-900 mb-2">Async Processing</h4>
                <ul className="space-y-2 text-sm text-amber-800">
                  <li>• Immediate upload confirmation</li>
                  <li>• Background processing queue</li>
                  <li>• WebSocket or push notifications</li>
                  <li>• Estimated processing time shown</li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="text-slate-900 mb-3">Example Upload Flow</h4>
              <pre className="text-sm bg-slate-900 text-slate-100 p-4 rounded overflow-x-auto">
{`// Step 1: Request presigned URL
POST /api/v1/upload/init
{
  "filename": "call_recording.mp3",
  "file_size": 15728640,
  "content_type": "audio/mpeg"
}

Response:
{
  "upload_id": "upl_abc123",
  "presigned_url": "https://s3.amazonaws.com/...",
  "expires_at": "2025-10-24T11:00:00Z",
  "chunk_size": 5242880
}

// Step 2: Upload directly to S3
PUT <presigned_url>
Content-Type: audio/mpeg
Body: <chunk_data>

// Step 3: Confirm upload and start processing
POST /api/v1/upload/complete
{
  "upload_id": "upl_abc123",
  "metadata": { ... }
}

Response:
{
  "analysis_id": "ana_xyz789",
  "status": "processing",
  "estimated_time_seconds": 45
}`}
              </pre>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
